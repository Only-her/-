#!/usr/bin/env python3
"""
main.py

1. 解析 input.yaml → 生成中间 IR
2. 生成并写入 Coq 的 concurrent.v 中的 ir_system 定义
3. 调用 coqc 验证 Coq 层
4. 调用 Frama-C 分析
5. 推理模块检测死锁/数据竞争
6. 整合并输出报告
"""

import os
import sys
import json

import yaml_parser
import ir_generator
import coq_interface        # 需要实现 generate_concurrent_v, verify_concurrent
import frama_c_interface
import reasoning
import report_generator

def main():
    if len(sys.argv) != 3:
        print("用法: python main.py <input.yaml> <C_source_file>")
        sys.exit(1)

    input_yaml = sys.argv[1]
    c_file     = sys.argv[2]

    # 1. 解析 YAML
    print("==== 1. 解析输入文件 ====")
    try:
        parsed = yaml_parser.parse_input_file(input_yaml)
        print(json.dumps(parsed, indent=2, ensure_ascii=False))
    except Exception as e:
        print("解析 YAML 失败:", e)
        sys.exit(1)

    # 2. 生成中间表示 IR
    print("\n==== 2. 生成中间表示 (IR) ====")
    try:
        ir = ir_generator.generate_ir(parsed)
        print(json.dumps(ir, indent=2, ensure_ascii=False))
    except Exception as e:
        print("生成 IR 失败:", e)
        sys.exit(1)

    # 写 IR 到文件（可选，方便调试）
    ir_path = os.path.join(os.path.dirname(__file__), "ir.json")
    with open(ir_path, "w", encoding="utf-8") as f:
        json.dump(ir, f, indent=2, ensure_ascii=False)
    print("IR 已写入:", ir_path)

    # 3. 生成 coq/concurrent.v 中的 ir_system 定义
    print("\n==== 3. 生成 Coq 并发系统定义 ====")
    coq_file = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            "..", "coq", "concurrent.v"))
    try:
        coq_interface.generate_concurrent_v(ir, coq_file)
        print("已更新 Coq 文件:", coq_file)
    except Exception as e:
        print("生成 concurrent.v 失败:", e)
        sys.exit(1)

    # 调用 Coq 验证
    print("\n==== 4. Coq 形式化验证 ====")
    coq_res = coq_interface.verify_concurrent(coq_file)
    print(coq_res)

    # 5. Frama-C 静态/形式化分析
    print("\n==== 5. Frama-C 分析 ====")
    frama_res = frama_c_interface.analyze_c_code(c_file)
    print(frama_res)

    # 6. 推理模块检测并发冲突
    print("\n==== 6. 推理模块检测 ====")
    deadlocks       = reasoning.detect_deadlocks(ir)
    data_races      = reasoning.detect_data_races(ir)
    lock_violations = reasoning.detect_lock_violations(ir)
    print("Deadlocks:", deadlocks or "None")
    print("Data races:", data_races or "None")
    print("Lock violations:", lock_violations or "None")

    # 7. 整合报告
    print("\n==== 7. 生成最终报告 ====")
    report = report_generator.generate_report(
        coq_res, frama_res,
        deadlocks, data_races, lock_violations
    )
    print(report)


if __name__ == "__main__":
    main()