# src/python/report_generator.py

from typing import List, Tuple, Any

def generate_report(
    coq_result: str,
    frama_c_result: str,
    deadlocks: List[List[str]],
    data_races: List[Tuple[int,int]],
    lock_violations: List[Tuple[int,str]]
) -> str:
    """
    整合 Coq、Frama-C 及推理模块结果，生成最终报告。
    """
    lines = []
    lines.append("==============================================")
    lines.append("           并发逻辑形式化验证报告")
    lines.append("==============================================\n")

    lines.append("----- Coq 形式化验证结果 -----")
    lines.append(coq_result or "无输出")
    lines.append("")

    lines.append("----- Frama-C 分析结果 -----")
    lines.append(frama_c_result or "无输出")
    lines.append("")

    lines.append("----- 并发冲突检测（推理模块） -----")
    lines.append("死锁环路:")
    if deadlocks:
        for cycle in deadlocks:
            lines.append("  - " + " -> ".join(cycle))
    else:
        lines.append("无")
    lines.append("数据竞态:")
    if data_races:
        for p, q in data_races:
            lines.append(f"  - ({p}, {q})")
    else:
        lines.append("无")
    lines.append("锁使用违规:")
    if lock_violations:
        for pid, desc in lock_violations:
            lines.append(f"  - 进程 {pid}: {desc}")
    else:
        lines.append("无")
    lines.append("\n==============================================")
    return "\n".join(lines)