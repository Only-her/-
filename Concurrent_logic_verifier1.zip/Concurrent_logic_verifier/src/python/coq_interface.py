# src/python/coq_interface.py

import os
import subprocess
import json

def generate_concurrent_v(ir: dict, coq_file_path: str) -> None:
    """
    将 IR（Python dict）注入到 concurrent.v 中的 ir_system 定义。
    """
    procs = ir["system"]["processes"]
    lines = []
    lines.append("Definition ir_system : System :=")
    lines.append("  [")
    for p in procs:
        pid = p["id"]
        act_lits = []
        for a in p["actions"]:
            if a == "lock":
                act_lits.append("Lock 0")
            elif a == "unlock":
                act_lits.append("Unlock 0")
            elif a == "critical":
                act_lits.append("Critical")
            else:
                act_lits.append(f'Other "{a}"')
        lines.append(f"    mkProcess {pid} [{'; '.join(act_lits)}];")
    if procs:
        # 去掉最后的分号
        last = lines[-1]
        if last.endswith(";"):
            lines[-1] = last[:-1]
    lines.append("  ].")

    # 读取并替换
    with open(coq_file_path, "r", encoding="utf-8") as f:
        src = f.read().splitlines()
    out = []
    in_block = False
    for l in src:
        if l.strip().startswith("Definition ir_system"):
            out.extend(lines)
            in_block = True
        elif in_block:
            if l.strip().startswith("Theorem ir_system_valid"):
                in_block = False
                out.append("" )
                out.append(l)
            # 跳过原 ir_system 定义行
        else:
            out.append(l)
    with open(coq_file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(out))

def verify_concurrent(coq_file_path: str) -> str:
    """
    在 concurrent.v 所在目录运行 coqc，返回结果字符串。
    """
    coq_dir, fname = os.path.split(coq_file_path)
    try:
        r = subprocess.run(
            ["coqc", fname],
            cwd=coq_dir,
            capture_output=True, text=True
        )
    except FileNotFoundError:
        return "Coq 编译器 (coqc) 未找到，请检查安装。"
    if r.returncode == 0:
        return "Coq verification succeeded."
    else:
        return (
            f"Coq verification failed (code {r.returncode}):\n"
            f"Stdout:\n{r.stdout}\nStderr:\n{r.stderr}"
        )