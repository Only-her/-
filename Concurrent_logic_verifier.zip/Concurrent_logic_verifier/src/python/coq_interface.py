# src/python/coq_interface.py

import os
import subprocess
import json


def generate_coq_ir_file(ir_file_path: str) -> None:
    """
    从 IR JSON 文件中读取数据，并生成 Coq 文件 (ir_generated.v)。

    生成的 Coq 文件将定义一个字符串常量 my_ir，包含 IR 的 JSON 表示。
    文件生成路径为：<项目根>/src/coq/ir_generated.v（相对于当前模块）。

    参数:
        ir_file_path: 包含 IR JSON 数据的文件路径。

    异常:
        如果读取或写入文件时发生错误，将抛出异常。
    """
    # 获取当前模块所在目录，并构造 Coq 目录路径（相对于 src/python/）
    current_dir = os.path.dirname(os.path.abspath(__file__))
    coq_dir = os.path.abspath(os.path.join(current_dir, "..", "coq"))
    output_file = os.path.join(coq_dir, "ir_generated.v")

    # 读取 IR JSON 数据
    try:
        with open(ir_file_path, "r", encoding="utf-8") as f:
            ir_data = json.load(f)
    except Exception as e:
        raise Exception(f"读取 IR 文件失败：{str(e)}")

    # 将 IR 数据转换为 JSON 字符串
    ir_json_str = json.dumps(ir_data)
    # 为在 Coq 中正确表示该字符串，再次进行转义，得到标准的 Coq 字符串字面值
    coq_string_literal = json.dumps(ir_json_str)

    # 构造 Coq 文件内容，其中定义了一个名为 my_ir 的字符串常量
    coq_content = (
            "(* Auto-generated IR file *)\n"
            "Definition my_ir : string := " + coq_string_literal + " .\n"
    )

    try:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(coq_content)
    except Exception as e:
        raise Exception(f"写入 Coq IR 文件失败：{str(e)}")


def verify_with_coq(ir_file_path: str) -> str:
    """
    调用 Coq 进行形式化验证。

    实现流程：
      1. 根据给定的 IR JSON 文件生成 Coq 文件 ir_generated.v，
         该文件中定义了 my_ir 常量供 Coq 证明脚本使用。
      2. 调用 Coq 编译器（coqc）对 proofs.v 进行编译执行，
         从而触发 Coq 的自动证明。

    参数:
        ir_file_path: 指定 IR JSON 文件的路径，由 ir_generator 模块生成。

    返回:
        验证结果字符串。如果验证成功，返回成功信息；如果失败，
        则返回包含返回码、Stdout 与 Stderr 详细信息的错误描述。
    """
    # 1. 生成 Coq 使用的 IR 文件
    try:
        generate_coq_ir_file(ir_file_path)
    except Exception as e:
        return f"生成 Coq IR 文件失败：{str(e)}"

    # 2. 构造 proofs.v 的绝对路径（假设 proofs.v 位于 ../coq/ 目录下）
    current_dir = os.path.dirname(os.path.abspath(__file__))
    proofs_file = os.path.abspath(os.path.join(current_dir, "..", "coq", "proofs.v"))

    # 3. 使用 subprocess 调用 coqc 编译 proofs.v 文件
    try:
        result = subprocess.run(
            ["coqc", proofs_file],
            capture_output=True,
            text=True,
            check=False  # 不自动抛异常，通过 returncode 判断
        )

        if result.returncode == 0:
            return "Coq verification succeeded.\n" + result.stdout
        else:
            error_message = (
                    f"Coq verification failed with return code {result.returncode}.\n"
                    "Stdout:\n" + result.stdout + "\nStderr:\n" + result.stderr
            )
            return error_message
    except FileNotFoundError:
        return "Coq 编译器 (coqc) 未找到，请确保 Coq 已正确安装并在 PATH 中。"
    except Exception as e:
        return f"调用 Coq 编译器时发生错误：{str(e)}"


if __name__ == "__main__":
    # 命令行测试：传入 IR JSON 文件路径，执行 Coq 验证
    import sys

    if len(sys.argv) < 2:
        print("用法: python coq_interface.py <ir_file.json>")
        exit(1)
    ir_file = sys.argv[1]
    verification_result = verify_with_coq(ir_file)
    print(verification_result)
