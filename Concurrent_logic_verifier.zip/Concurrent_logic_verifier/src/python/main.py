#!/usr/bin/env python3
import os
import sys
import json
import subprocess
from pathlib import Path
from datetime import datetime
from report_generator import generate_report_html

script_dir = os.path.dirname(__file__)
project_src = os.path.abspath(os.path.join(script_dir, ".."))
sys.path.insert(0, script_dir)
sys.path.insert(0, project_src)

import yaml_parser
import ir_generator
import coq_interface
import frama_c_interface
import reasoning
import report_generator

def generate_counterexample_image(dot_path: str, img_path: str) -> bool:
    """生成反例图像"""
    if not os.path.isfile(dot_path):
        print(f"未找到 dot 文件: {dot_path}")
        return False
    try:
        subprocess.run(["dot", "-Tpng", dot_path, "-o", img_path], check=True)
        return True
    except Exception as e:
        print("Graphviz dot 转换失败:", e)
        return False

def main():
    if len(sys.argv) < 3:
        print("用法: python main.py <input.yaml> <C_source_file> [counterexample.dot]")
        sys.exit(1)

    input_yaml = sys.argv[1]
    c_file = sys.argv[2]
    counterexample_dot = sys.argv[3] if len(sys.argv) > 3 else None
    counterexample_img = None

    print("==== 1. 解析输入文件 ====")
    try:
        parsed = yaml_parser.parse_input_file(input_yaml)
        print(json.dumps(parsed, indent=2, ensure_ascii=False))
    except Exception as e:
        print("解析 YAML 失败:", e)
        sys.exit(1)

    print("\n==== 2. 生成中间表示 (IR) ====")
    try:
        ir = ir_generator.generate_ir(parsed)
        print(json.dumps(ir, indent=2, ensure_ascii=False))
    except Exception as e:
        print("生成 IR 失败:", e)
        sys.exit(1)

    ir_path = os.path.join(script_dir, "ir.json")
    with open(ir_path, "w", encoding="utf-8") as f:
        json.dump(ir, f, indent=2, ensure_ascii=False)

    print("\n==== 3. 生成 Coq 并发系统定义 ====")
    coq_file = os.path.join(project_src, "coq", "concurrent.v")
    try:
        coq_interface.generate_concurrent_v(ir, coq_file)
    except Exception as e:
        print("生成 Coq 文件失败:", e)
        sys.exit(1)

    print("\n==== 4. Coq 形式化验证 ====")
    coq_res = coq_interface.verify_concurrent(coq_file)
    print(coq_res)

    print("\n==== 5. Frama-C 分析 ====")
    frama_res = frama_c_interface.analyze_c_code(c_file)
    print(frama_res)

    print("\n==== 6. 推理模块检测 ====")
    deadlocks = reasoning.detect_deadlocks(ir)
    data_races = reasoning.detect_data_races(ir)
    lock_violations = reasoning.detect_lock_violations(ir)

    print("Deadlocks:", deadlocks or "None")
    print("Data races:", data_races or "None")
    print("Lock violations:", lock_violations or "None")

    if counterexample_dot:
        print("\n==== 7. 生成模型检查反例图像 ====")
        img_path = os.path.join(project_src, "output", "counterexample.png")
        if generate_counterexample_image(counterexample_dot, img_path):
            counterexample_img = img_path
            print("反例图像已生成:", counterexample_img)

    print("\n==== 8. 生成最终 HTML 报告 ====")
    html_path = os.path.join(project_src, "output", "report.html")
    try:
        report_generator.generate_report_html(
            coq_result=coq_res,
            frama_c_result=frama_res,
            deadlocks=deadlocks,
            data_races=data_races,
            lock_violations=lock_violations,
            counterexample_trace="output/cex.png",
            output_path=html_path
        )
        print("HTML 报告已生成:", html_path)
    except Exception as e:
        print("生成 HTML 报告失败:", e)
        sys.exit(1)

if __name__ == "__main__":
    main()