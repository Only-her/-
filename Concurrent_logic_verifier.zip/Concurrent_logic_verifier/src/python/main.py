#!/usr/bin/env python3
"""
main.py

整合整个验证工具的各模块实现，流程如下：
1. 从 YAML 文件中读取并解析并发系统描述数据；
2. 利用 ir_generator 生成中间表示（IR），并写入 IR JSON 文件；
3. 调用 coq_interface 进行形式化验证，并获取 Coq 验证结果；
4. 调用 frama_c_interface 对 C 代码进行静态分析，并获取分析结果；
5. 利用 report_generator 整合结果生成最终验证报告；
6. 输出报告到屏幕。

用法:
    python main.py <input_yaml_file> <c_source_file>
例如:
    python main.py input.yaml ../frama_c/sample_code.c
"""

import os
import sys
import json

# 导入各子模块
import yaml_parser  # 用于解析 YAML 文件，文件位置：src/python/yaml_parser.py
import ir_generator  # 用于生成 IR，文件位置：src/python/ir_generator.py
import coq_interface  # 用于调用 Coq 进行形式化验证，文件位置：src/python/coq_interface.py
import frama_c_interface  # 用于调用 Frama-C 进行静态代码分析，文件位置：src/python/frama_c_interface.py
import report_generator  # 用于整合生成最终报告，文件位置：src/python/report_generator.py


def main():
    # 检查命令行参数：要求至少指定 YAML 输入文件和 C 代码文件路径
    if len(sys.argv) < 3:
        print("用法: python main.py <input_yaml_file> <c_source_file>")
        sys.exit(1)

    input_yaml_file = sys.argv[1]
    c_file_path = sys.argv[2]

    print("==== 1. 解析输入文件 ====")
    try:
        parsed_data = yaml_parser.parse_input_file(input_yaml_file)
        print("解析成功，数据如下:")
        print(json.dumps(parsed_data, indent=2, ensure_ascii=False))
    except Exception as e:
        print("解析 YAML 文件时发生错误:", e)
        sys.exit(1)

    print("\n==== 2. 生成中间表示 (IR) ====")
    try:
        ir = ir_generator.generate_ir(parsed_data)
        # 打印 IR 内容
        print("生成的 IR:")
        print(json.dumps(ir, indent=2, ensure_ascii=False))
    except Exception as e:
        print("生成 IR 时发生错误:", e)
        sys.exit(1)

    # 写入 IR 到文件（用于 Coq 验证）
    # 将 IR 写入与 main.py 同级的 "ir.json" 文件中
    ir_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ir.json")
    try:
        with open(ir_file_path, "w", encoding="utf-8") as f:
            json.dump(ir, f, indent=2, ensure_ascii=False)
        print("\nIR 已写入文件: ", ir_file_path)
    except Exception as e:
        print("写入 IR 文件时发生错误:", e)
        sys.exit(1)

    print("\n==== 3. 调用 Coq 形式化验证 ====")
    try:
        coq_result = coq_interface.verify_with_coq(ir_file_path)
        print("Coq 验证结果:")
        print(coq_result)
    except Exception as e:
        coq_result = f"调用 Coq 进行验证时发生错误: {e}"
        print(coq_result)

    print("\n==== 4. 调用 Frama-C 静态分析 ====")
    try:
        frama_c_result = frama_c_interface.analyze_c_code(c_file_path)
        print("Frama-C 分析结果:")
        print(frama_c_result)
    except Exception as e:
        frama_c_result = f"调用 Frama-C 进行分析时发生错误: {e}"
        print(frama_c_result)

    print("\n==== 5. 整合生成最终报告 ====")
    try:
        final_report = report_generator.generate_report(coq_result, frama_c_result)
        print(final_report)
    except Exception as e:
        print("生成最终报告时发生错误:", e)


if __name__ == "__main__":
    main()
