# src/python/yaml_parser.py

import yaml


class ParseError(Exception):
    """自定义解析错误异常类。"""
    pass


def parse_input_str(input_text: str) -> dict:
    """
    解析 YAML 格式的字符串，返回字典数据。

    参数:
        input_text: 包含 YAML 格式数据的字符串。

    返回:
        包含解析后数据的字典。

    异常:
        如果解析失败或数据结构不符合要求，则抛出 ParseError 异常。
    """
    try:
        data = yaml.safe_load(input_text)
    except yaml.YAMLError as e:
        raise ParseError("YAML 解析错误: " + str(e)) from e

    validate_data_structure(data)
    return data


def parse_input_file(filepath: str) -> dict:
    """
    从指定文件中读取并解析 YAML 数据，返回字典数据。

    参数:
        filepath: YAML 格式输入文件的路径。

    返回:
        包含解析后数据的字典。

    异常:
        如果文件读取或解析失败，或者数据结构不符合要求，则抛出 ParseError 异常。
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
    except Exception as e:
        raise ParseError("读取或解析文件时出错: " + str(e)) from e

    validate_data_structure(data)
    return data


def validate_data_structure(data):
    """
    验证解析后的数据结构是否符合要求：
    - 必须是字典类型。
    - 必须包含 "processes" 键，其值为进程定义列表。
      每个进程必须为字典，且包含 "id"（整型或可转换为整数）和 "actions"（字符串列表）键。
    - 必须包含 "synchronization" 键，其值为字符串。

    参数:
        data: 待验证的数据。

    异常:
        如果数据结构不合法，则抛出 ParseError 异常。
    """
    if not isinstance(data, dict):
        raise ParseError("输入数据必须是一个字典。")

    if "processes" not in data:
        raise ParseError("缺少 'processes' 键。")
    if not isinstance(data["processes"], list):
        raise ParseError("'processes' 的值必须为列表。")

    for idx, process in enumerate(data["processes"], start=1):
        if not isinstance(process, dict):
            raise ParseError(f"第 {idx} 个进程定义必须是字典。")
        if "id" not in process:
            raise ParseError(f"第 {idx} 个进程缺少 'id' 键。")
        if "actions" not in process:
            raise ParseError(f"第 {idx} 个进程缺少 'actions' 键。")
        # 验证 id 是否为整数或可转换为整数
        try:
            int(process["id"])
        except Exception:
            raise ParseError(f"第 {idx} 个进程的 'id' 必须为整数或可转换为整数。")
        # 验证 actions 是否为字符串列表
        if not isinstance(process["actions"], list):
            raise ParseError(f"第 {idx} 个进程的 'actions' 必须是列表。")
        for action in process["actions"]:
            if not isinstance(action, str):
                raise ParseError(f"第 {idx} 个进程的每个 action 必须是字符串。")

    if "synchronization" not in data:
        raise ParseError("缺少 'synchronization' 键。")
    if not isinstance(data["synchronization"], str):
        raise ParseError("'synchronization' 的值必须为字符串。")


if __name__ == "__main__":
    # 直接运行该模块时，可通过命令行传入 YAML 文件路径以进行测试解析
    import sys

    if len(sys.argv) < 2:
        print("用法: python yaml_parser.py <input_file.yaml>")
    else:
        filepath = sys.argv[1]
        try:
            parsed = parse_input_file(filepath)
            print("解析成功，数据如下:")
            print(parsed)
        except ParseError as e:
            print("解析错误:", e)
