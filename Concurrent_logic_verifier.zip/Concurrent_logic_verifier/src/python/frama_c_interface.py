# src/python/frama_c_interface.py

import os
import subprocess


def analyze_c_code(c_file_path: str) -> str:
    """
    使用 Frama-C 对指定的 C 代码文件进行静态分析。

    功能：
      1. 检查 C 文件是否存在。
      2. 调用 Frama-C 命令行工具进行静态分析，使用 -val 选项启用值分析，
         并显示进度信息（-val-show-progress）。
      3. 捕获 Frama-C 输出，包括标准输出和标准错误，并根据返回码生成分析结果报告。

    参数:
        c_file_path: 待分析的 C 代码文件路径。

    返回:
        分析结果的字符串。如果分析成功，包含 Frama-C 的输出报告；
        如果失败，则返回包含错误信息的描述字符串。
    """
    # 检查指定的 C 文件是否存在
    if not os.path.isfile(c_file_path):
        return f"错误: C 文件 '{c_file_path}' 不存在。"

    # 定义 Frama-C 命令和参数
    # -val 启动值分析，-val-show-progress 显示进度信息
    cmd = ["frama-c", "-val", "-val-show-progress", c_file_path]

    try:
        # 调用 subprocess.run 执行 Frama-C 命令
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )
    except FileNotFoundError:
        return "错误: Frama-C 工具未找到，请确保已正确安装并且在系统 PATH 中。"
    except Exception as e:
        return f"调用 Frama-C 时发生错误：{str(e)}"

    # 根据返回码判断分析是否成功
    if result.returncode == 0:
        return "Frama-C 分析成功:\n" + result.stdout
    else:
        return (
            f"Frama-C 分析失败 (返回码 {result.returncode}):\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("用法: python frama_c_interface.py <C_file_path>")
        sys.exit(1)

    c_file_path = sys.argv[1]
    analysis_result = analyze_c_code(c_file_path)
    print(analysis_result)
