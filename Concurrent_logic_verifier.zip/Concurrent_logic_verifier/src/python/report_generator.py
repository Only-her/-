# src/python/report_generator.py

def generate_report(coq_result: str, frama_c_result: str) -> str:
    """
    整合 Coq 与 Frama-C 的验证/分析结果，生成最终的验证报告。

    参数:
        coq_result: 来自 Coq 验证的结果字符串（包含成功信息或错误描述）。
        frama_c_result: 来自 Frama-C 静态分析的结果字符串（包含分析报告或错误信息）。

    返回:
        一份整合后的报告文本，包含标题、各部分结果及分隔符，便于阅读和保存。
    """
    report_lines = []
    report_lines.append("==============================================")
    report_lines.append("           并发逻辑形式化验证报告")
    report_lines.append("==============================================")
    report_lines.append("")
    report_lines.append("----- Coq 形式化验证结果 -----")
    report_lines.append(coq_result)
    report_lines.append("")
    report_lines.append("----- Frama-C 静态分析结果 -----")
    report_lines.append(frama_c_result)
    report_lines.append("")
    report_lines.append("==============================================")
    return "\n".join(report_lines)


if __name__ == "__main__":
    import sys

    # 如果直接运行此模块，则从命令行接收两个文本文件的路径，
    # 分别存放 Coq 和 Frama-C 的结果，然后生成最终报告并打印
    if len(sys.argv) < 3:
        print("用法: python report_generator.py <coq_result.txt> <frama_c_result.txt>")
        sys.exit(1)

    coq_result_file = sys.argv[1]
    frama_c_result_file = sys.argv[2]

    try:
        with open(coq_result_file, "r", encoding="utf-8") as f:
            coq_result = f.read()
    except Exception as e:
        print(f"读取 {coq_result_file} 时发生错误: {e}")
        sys.exit(1)

    try:
        with open(frama_c_result_file, "r", encoding="utf-8") as f:
            frama_c_result = f.read()
    except Exception as e:
        print(f"读取 {frama_c_result_file} 时发生错误: {e}")
        sys.exit(1)

    report = generate_report(coq_result, frama_c_result)
    print(report)
