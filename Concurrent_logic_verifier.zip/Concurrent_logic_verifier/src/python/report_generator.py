import os
from typing import List, Tuple, Optional
from datetime import datetime
import graphviz

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh">
<head>
  <meta charset="UTF-8">
  <title>并发逻辑形式化验证报告</title>
  <style>
    body {{
      font-family: "Microsoft YaHei", sans-serif;
      margin: 2em;
      background-color: #f9f9f9;
    }}
    h1 {{ color: #2c3e50; }}
    .section {{
      border-left: 5px solid #3498db;
      padding-left: 15px;
      margin-top: 2em;
    }}
    pre {{
      background-color: #ecf0f1;
      padding: 1em;
      overflow-x: auto;
      white-space: pre-wrap;
    }}
    .warning {{ color: #e67e22; }}
    .error {{ color: #c0392b; font-weight: bold; }}
    .ok {{ color: #27ae60; }}
  </style>
</head>
<body>
  <h1>并发逻辑形式化验证报告</h1>
  <p><strong>生成时间：</strong>{timestamp}</p>

  <div class="section">
    <h2>1. Coq 形式化验证</h2>
    <pre>{coq_result}</pre>
  </div>

  <div class="section">
    <h2>2. Frama-C 分析结果</h2>
    <pre>{frama_c_result}</pre>
  </div>

  <div class="section">
    <h2>3. 并发推理模块分析</h2>
    <h3>3.1 死锁检测</h3>
    {deadlocks}
    <h3>3.2 数据竞态</h3>
    {data_races}
    <h3>3.3 锁使用违规</h3>
    {lock_violations}
  </div>

  {counterexample_section}
</body>
</html>
"""

def _render_list(title: str, items: List[str], ok_text: str = "无") -> str:
    if not items:
        return f"<p class='ok'>{ok_text}</p>"
    return "<ul>" + "".join(f"<li>{item}</li>" for item in items) + "</ul>"

def _format_deadlocks(deadlocks: List[List[str]]) -> str:
    return _render_list("死锁", [" → ".join(cycle) for cycle in deadlocks])

def _format_data_races(data_races: List[Tuple[int, int]]) -> str:
    return _render_list("数据竞态", [f"线程 {p} 与 线程 {q}" for p, q in data_races])

def _format_lock_violations(lock_violations: List[Tuple[int, str]]) -> str:
    return _render_list("锁违规", [f"线程 {pid}：{desc}" for pid, desc in lock_violations])

def _render_counterexample(img_path: Optional[str]) -> str:
    if not img_path or not os.path.exists(img_path):
        return ""
    return f"""
    <div class="section">
      <h2>4. 模型检查反例可视化</h2>
      <img src="{img_path}" alt="反例轨迹" style="max-width:100%;border:1px solid #ccc;">
    </div>
    """

def generate_counterexample_graph(trace: List[str], output_img_path: str) -> None:
    """
    根据反例状态序列生成 Graphviz 状态图。
    参数:
        trace: 状态序列，每个元素为状态字符串。
        output_img_path: 输出 PNG 文件路径。
    """
    dot = graphviz.Digraph(format="png")
    for i, state in enumerate(trace):
        dot.node(str(i), state)
        if i > 0:
            dot.edge(str(i - 1), str(i))
    dot.render(output_img_path, cleanup=True)

def generate_report_html(
    coq_result: str,
    frama_c_result: str,
    deadlocks: List[List[str]],
    data_races: List[Tuple[int, int]],
    lock_violations: List[Tuple[int, str]],
    counterexample_trace: Optional[List[str]] = None,
    output_path: str = "output/report.html"
) -> str:
    # 如果提供了反例轨迹，生成图像
    counterexample_img = None
    if counterexample_trace:
        img_file_base = "output/counterexample"
        generate_counterexample_graph(counterexample_trace, img_file_base)
        counterexample_img = img_file_base + ".png"

    html = HTML_TEMPLATE.format(
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        coq_result=coq_result,
        frama_c_result=frama_c_result,
        deadlocks=_format_deadlocks(deadlocks),
        data_races=_format_data_races(data_races),
        lock_violations=_format_lock_violations(lock_violations),
        counterexample_section=_render_counterexample(counterexample_img)
    )

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return output_path