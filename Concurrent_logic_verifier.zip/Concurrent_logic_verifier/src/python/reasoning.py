# src/python/reasoning.py

from collections import defaultdict
from itertools import combinations
from typing import Any, Dict, List, Tuple, Set

class ReasoningError(Exception):
    """推理模块通用异常。"""
    pass

def detect_deadlocks(ir: Dict[str, Any]) -> List[List[str]]:
    """
    根据 IR 中各进程的 lock/unlock 序列，构建锁依赖图并检测环路（死锁）。
    
    IR["system"]["processes"] 格式：
      [{"id": int, "actions": [str, ...]}, ...]
    动作字符串以 "lock" 或 "lock_<name>" 开头表示加锁，
    以 "unlock" 或 "unlock_<name>" 开头表示解锁。
    
    返回：
      deadlock_cycles: List of cycles, 每个 cycle 为一条锁名列表，
                       如 ["A","B","C","A"]。
      无环路时返回 []。
    """
    # 构建依赖边集：若进程在持有锁 held 的情况下又 lock name，则添加 (held->name)
    edges: Set[Tuple[str, str]] = set()
    for proc in ir["system"]["processes"]:
        held_stack: List[str] = []
        for act in proc["actions"]:
            if act.startswith("lock"):
                # 解析锁名
                parts = act.split("_", 1)
                name = parts[1] if len(parts) == 2 else "mutex"
                # 对当前所有已持有的锁，添加 held->name 边
                for held in held_stack:
                    edges.add((held, name))
                held_stack.append(name)
            elif act.startswith("unlock"):
                parts = act.split("_", 1)
                name = parts[1] if len(parts) == 2 else "mutex"
                if name in held_stack:
                    held_stack.remove(name)

    # 构建邻接表
    graph: Dict[str, Set[str]] = defaultdict(set)
    for u, v in edges:
        graph[u].add(v)

    # DFS 寻找环路
    visited: Set[str] = set()
    onpath: Set[str] = set()
    cycles: List[List[str]] = []

    def dfs(node: str, path: List[str]):
        visited.add(node)
        onpath.add(node)
        for nei in graph.get(node, []):
            if nei not in visited:
                dfs(nei, path + [nei])
            elif nei in onpath:
                # 找到一个环：从 path 中第一次出现 nei 开始，到后面再遇到 nei
                try:
                    idx = path.index(nei)
                    cycle = path[idx:] + [nei]
                except ValueError:
                    cycle = [nei, nei]
                cycles.append(cycle)
        onpath.remove(node)

    for start in graph:
        if start not in visited:
            dfs(start, [start])

    return cycles


def detect_data_races(ir: Dict[str, Any]) -> List[Tuple[int, int]]:
    """
    检测数据竞态：若多个进程在“未持锁”状态下执行 'critical' 操作，
    则认为这些进程之间可能发生竞态。
    
    返回所有可能的进程对 (pid1, pid2)，pid1 < pid2。
    """
    unprotected: Set[int] = set()
    for proc in ir["system"]["processes"]:
        pid = proc["id"]
        locked = False
        for act in proc["actions"]:
            if act.startswith("lock"):
                locked = True
            elif act.startswith("unlock"):
                locked = False
            elif act == "critical" and not locked:
                unprotected.add(pid)
                break

    races: List[Tuple[int, int]] = []
    for p, q in combinations(sorted(unprotected), 2):
        races.append((p, q))
    return races


def detect_lock_violations(ir: Dict[str, Any]) -> List[Tuple[int, str]]:
    """
    检测锁使用违规，包括：
      1. 重入锁：lock 同一把锁而未先 unlock
      2. 未加锁便 unlock
      3. 进程结束时仍有未释放的锁
    
    返回列表，每项为 (pid, 描述字符串)。
    """
    violations: List[Tuple[int, str]] = []

    for proc in ir["system"]["processes"]:
        pid = proc["id"]
        held_stack: List[str] = []
        for idx, act in enumerate(proc["actions"]):
            if act.startswith("lock"):
                parts = act.split("_", 1)
                name = parts[1] if len(parts) == 2 else "mutex"
                if name in held_stack:
                    violations.append((pid, f"重入锁 '{name}'，第 {idx} 步"))
                held_stack.append(name)

            elif act.startswith("unlock"):
                parts = act.split("_", 1)
                name = parts[1] if len(parts) == 2 else "mutex"
                if name not in held_stack:
                    violations.append((pid, f"未加锁便 unlock '{name}'，第 {idx} 步"))
                else:
                    held_stack.remove(name)

        if held_stack:
            for name in held_stack:
                violations.append((pid, f"未释放的锁 '{name}'"))

    return violations


if __name__ == "__main__":
    # 样例 IR，用于模块自测
    sample_ir = {
        "ir_version": "1.0",
        "system": {
            "processes": [
                {"id": 1, "actions": ["lock_X", "lock_Y", "unlock_X", "unlock_Y"]},
                {"id": 2, "actions": ["lock_Y", "lock_X", "unlock_Y", "unlock_X"]},
                {"id": 3, "actions": ["critical"]},
                {"id": 4, "actions": ["unlock", "lock"]},
                {"id": 5, "actions": ["lock_A", "lock_A", "unlock_A"]},
            ],
            "synchronization": {"method": "mutex"}
        },
        "metadata": {}
    }

    print("Deadlocks detected:", detect_deadlocks(sample_ir))
    # 预期: [['X','Y','X']]

    print("Data races detected:", detect_data_races(sample_ir))
    # 预期: [(3,)]

    print("Lock violations:", detect_lock_violations(sample_ir))
    # 预期: [(4, "未加锁便 unlock 'mutex'..."), (5, "重入锁 'A'..."), (1 or 2 if missing)]