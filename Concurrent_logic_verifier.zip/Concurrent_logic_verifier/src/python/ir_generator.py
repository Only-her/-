# src/python/ir_generator.py

import datetime
import json


def generate_ir(parsed_data: dict) -> dict:
    """
    根据解析后的数据生成中间表示 (IR)。

    生成的 IR 结构包括：
      - ir_version: 字符串，表示 IR 的版本号
      - system: 包含以下内容：
          - processes: 一个进程列表，每个进程包含
              - id: 整数型进程标识（确保转换为 int）
              - actions: 字符串列表，表示进程执行的动作序列
          - synchronization: 一个字典，目前包含同步方法信息（例如“mutex”）
      - metadata: 元数据信息，记录 IR 的生成来源和时间戳

    参数:
        parsed_data: 由 parser 模块解析后的字典数据，要求包含 "processes"（列表格式）和 "synchronization"（字符串）。

    返回:
        一个字典对象，表示中间表示（IR）。
    """
    # 转换进程数据：确保 id 转换成整数
    processes = []
    for process in parsed_data.get("processes", []):
        try:
            proc_id = int(process["id"])
        except Exception as e:
            raise ValueError(f"无法将进程 id 转换为整数，原始数据: {process['id']}") from e

        actions = process["actions"]
        # 如果需要进一步检查 actions 中的内容，可在此扩展逻辑
        processes.append({
            "id": proc_id,
            "actions": actions
        })

    # 构造 system 部分
    system = {
        "processes": processes,
        "synchronization": {
            "method": parsed_data.get("synchronization", "")
        }
    }

    # 附加元数据信息
    metadata = {
        "generated_by": "ir_generator.py",
        "timestamp": datetime.datetime.now().isoformat()
    }

    # 组合生成完整的 IR 数据
    ir = {
        "ir_version": "1.0",
        "system": system,
        "metadata": metadata
    }

    return ir


if __name__ == "__main__":
    """
    当直接运行此模块时，从命令行参数接收 YAML 格式的输入文件路径，
    调用 parser 模块读取并解析文件，然后生成 IR 并以 JSON 格式输出。

    用法:
        python ir_generator.py <input_file.yaml>
    """
    import sys

    try:
        from parser import parse_input_file
    except ImportError as e:
        print("导入 parser 模块失败，请确保 yaml_parser.py 存在于相应目录下。")
        sys.exit(1)

    if len(sys.argv) < 2:
        print("用法: python ir_generator.py <input_file.yaml>")
        sys.exit(1)

    input_file = sys.argv[1]
    try:
        # 利用 parser 模块读取并解析 YAML 文件
        parsed_data = parse_input_file(input_file)
        # 根据解析结果生成中间表示 (IR)
        ir = generate_ir(parsed_data)
        # 以格式化的 JSON 输出 IR
        print(json.dumps(ir, ensure_ascii=False, indent=2))
    except Exception as e:
        print("错误:", e)
