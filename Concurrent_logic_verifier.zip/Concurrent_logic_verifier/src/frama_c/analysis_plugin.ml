(*
  src/frama_c/analysis_plugin.ml
  一个完整功能的 Frama-C 插件，用于检查 C 代码中锁/解锁调用是否匹配。

  功能说明：
  - 遍历被分析程序的所有函数（GFun 节点）。
  - 对每个函数，利用自定义访问器（lock_counter_visitor）遍历其语句，
    统计 "pthread_mutex_lock" 与 "pthread_mutex_unlock" 的调用次数。
  - 如果一个函数内调用次数不匹配，则输出警告提示；否则输出调试信息提示匹配正常。
*)

open Cil_types
open Cil
open Plugin

(* 插件名和简称定义 *)
let name = "concurrent_checker"
let shortname = "cchecker"

(* 定义一个访问器类，统计当前函数中对锁与解锁调用的次数 *)
class lock_counter_visitor = object (self)
  inherit Cil.nopCilVisitor

  val mutable lock_count = 0
  val mutable unlock_count = 0

  method get_counts = (lock_count, unlock_count)

  method! vinst (i: instr) : instr list visitAction =
    match i with
    | Call (_, Lval(Var vi, _), _, _) ->
        (* 根据函数名判断是否为锁/解锁调用 *)
        (if vi.vname = "pthread_mutex_lock" then
            lock_count <- lock_count + 1
         else if vi.vname = "pthread_mutex_unlock" then
            unlock_count <- unlock_count + 1);
        DoChildren
    | _ ->
        DoChildren
end

(* 对一个函数定义 fd 进行锁/解锁匹配分析 *)
let process_function (fd: fundec) =
  let visitor = new lock_counter_visitor in
  visitCilFunction (visitor :> cilVisitor) fd;
  let (lock, unlock) = visitor#get_counts in
  if lock <> unlock then
    Kernel.warning ~once:true ~current:true
      "Function %s: pthread_mutex_lock=%d, pthread_mutex_unlock=%d (mismatch)"
      fd.svar.vname lock unlock
  else
    Kernel.feedback "Function %s: lock/unlock balanced (%d calls)"
      fd.svar.vname lock

(* 插件主入口：遍历全局 AST 中的所有函数并调用 process_function 进行分析 *)
let main () =
  List.iter
    (fun glob ->
       match glob with
       | GFun(fd, _) -> process_function fd
       | _ -> ())
    (Globals.get_funs ());
  Kernel.feedback "Concurrent Checker Plugin analysis complete."

(* 将插件主入口注册到 Frama-C 主循环中 *)
let () = Db.Main.extend main
