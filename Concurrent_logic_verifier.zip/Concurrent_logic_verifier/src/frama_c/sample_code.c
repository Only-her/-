/* src/frama_c/sample_code.c */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// 全局互斥锁初始化
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/*
 * good_function: 正确使用锁
 * 获取互斥锁，进入临界区后释放锁。
 */
void* good_function(void* arg) {
    // 加锁
    if(pthread_mutex_lock(&mutex) != 0){
        perror("pthread_mutex_lock in good_function");
        return NULL;
    }

    // 临界区
    printf("In good_function: inside critical section\n");

    // 释放锁
    if(pthread_mutex_unlock(&mutex) != 0){
        perror("pthread_mutex_unlock in good_function");
        return NULL;
    }

    return NULL;
}

/*
 * bad_function: 不正确的锁使用
 * 获取互斥锁后未释放，会导致锁不匹配的问题。
 */
void* bad_function(void* arg) {
    // 加锁
    if(pthread_mutex_lock(&mutex) != 0){
        perror("pthread_mutex_lock in bad_function");
        return NULL;
    }

    // 临界区
    printf("In bad_function: lock acquired but not released\n");

    // 故意不调用 pthread_mutex_unlock
    return NULL;
}

/*
 * main 函数: 创建线程执行 good_function 与 bad_function，并等待结束
 */
int main() {
    pthread_t t1, t2;

    // 创建线程，执行正确的锁使用函数
    if(pthread_create(&t1, NULL, good_function, NULL) != 0){
        perror("pthread_create for good_function");
        exit(EXIT_FAILURE);
    }

    // 创建线程，执行错误的锁使用函数
    if(pthread_create(&t2, NULL, bad_function, NULL) != 0){
        perror("pthread_create for bad_function");
        exit(EXIT_FAILURE);
    }

    // 等待两个线程结束
    if(pthread_join(t1, NULL) != 0){
        perror("pthread_join for t1");
    }

    if(pthread_join(t2, NULL) != 0){
        perror("pthread_join for t2");
    }

    return 0;
}
