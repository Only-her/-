# tla_generator.py
import yaml

def format_value(val, type_hint=None):
    """将 Python 基础类型值格式化为 TLA+ 表达式字符串。"""
    if isinstance(val, bool):
        return "TRUE" if val else "FALSE"
    elif isinstance(val, (int, float)):
        return str(val)
    elif isinstance(val, str):
        return f'"{val}"'
    elif isinstance(val, dict):
        # 先构建每一项的 key_str 和 value_str，再拼接
        items = []
        for k, v in val.items():
            if isinstance(k, str):
                key_str = f'"{k}"'
            else:
                key_str = str(k)
            val_str = format_value(v)
            items.append(f'{key_str} |-> {val_str}')
        return "[ " + ", ".join(items) + " ]"
    elif isinstance(val, list):
        elements = [format_value(x) for x in val]
        if type_hint == 'set':
            return "{ " + ", ".join(elements) + " }"
        else:
            return "<< " + ", ".join(elements) + " >>"
    else:
        return str(val)

def generate_spec(yaml_path, module_name="Spec"):
    """
    从给定的 YAML 文件路径读取模型配置，生成对应的 TLA+ 规范和配置内容。
    返回生成的 TLA+ 文件路径和 CFG 文件路径。
    """
    # 读取 YAML 配置
    with open(yaml_path, 'r') as f:
        data = yaml.safe_load(f)

    # 准备 TLA+ 规范文本生成
    lines = [f"---- MODULE {module_name} ----"]
    # 根据模型需要扩展标准模块 (如 Naturals 用于算术, Sequences 用于序列)
    need_naturals = need_sequences = False
    for var in data.get('variables', []):
        init_val = var.get('init')
        if isinstance(init_val, (int, float)):
            need_naturals = True
        if isinstance(init_val, list):
            need_sequences = True
        if isinstance(init_val, dict):
            # 若初始值中有数字，也需要 Naturals
            if any(isinstance(v, (int, float)) for v in init_val.values()):
                need_naturals = True
    for trans in data.get('transitions', []):
        cond = str(trans.get('condition', ''))
        # 简单检查条件或动作中是否出现算术/比较运算符
        if any(op in cond for op in ['<', '>', '+', '-', '=']):
            need_naturals = True
        for expr in (trans.get('actions') or {}).values():
            if isinstance(expr, str) and any(op in expr for op in ['<', '>', '+', '-', '=']):
                need_naturals = True
    if need_naturals or data.get('constants'):
        # 如果使用算术运算或定义了常量，扩展 Naturals 模块
        # （TLA+ 中整数/自然数运算需要引入标准模块定义）
        lines.append("EXTENDS Naturals" + (", Sequences" if need_sequences else ""))
    elif need_sequences:
        lines.append("EXTENDS Sequences")

    # 常量声明（如果 YAML 提供了 constants 节）
    constants = data.get('constants', {})
    if constants:
        const_names = ", ".join(constants.keys())
        lines.append(f"CONSTANTS {const_names}")

    # 状态变量声明
    var_names = [v['name'] for v in data.get('variables', [])]
    if var_names:
        lines.append("VARIABLES " + ", ".join(var_names))

    # 初始状态定义
    init_clauses = []
    for var in data.get('variables', []):
        name = var['name']
        init_val = var.get('init')
        type_hint = var.get('type')
        tla_val = format_value(init_val, type_hint)
        init_clauses.append(f"{name} = {tla_val}")
    if init_clauses:
        lines.append("Init == " + " /\\ ".join(init_clauses))

    # 转移关系 (Next) 定义
    transition_branches = []
    for trans in data.get('transitions', []):
        cond = str(trans.get('condition', 'TRUE'))
        # 将常见逻辑符号替换为 TLA+ 符号（&&->/\，||->\/，==->=）
        cond_tla = cond.replace("&&", "/\\").replace("||", "\\/").replace("==", "=")
        cond_tla = cond_tla.replace("true", "TRUE").replace("false", "FALSE")
        actions = trans.get('actions') or {}
        updated_vars = set()
        action_clauses = []
        # 按目标变量分组处理，支持对函数（如 pc[i]）的更新
        updates_by_var = {}
        for target, expr in actions.items():
            target = str(target)
            expr_str = str(expr).replace("&&", "/\\").replace("||", "\\/").replace("==", "=")
            expr_str = expr_str.replace("true", "TRUE").replace("false", "FALSE")
            # 检查 target 是否为形如 var[key] 的形式
            if '[' in target and target.endswith(']'):
                base_var = target.split('[', 1)[0].strip()
                index_expr = target[target.find('[') + 1 : -1]  # 提取方括号内的内容
                updates_by_var.setdefault(base_var, []).append((index_expr, expr_str))
            else:
                updates_by_var.setdefault(target, []).append((None, expr_str))
        # 构造动作子句
        for var, updates in updates_by_var.items():
            if updates[0][0] is None:
                # 简单变量赋值
                _, val_expr = updates[0]
                action_clauses.append(f"{var}' = {val_expr}")
                updated_vars.add(var)
            else:
                # 函数/数组的一个或多个元素赋值
                except_clauses = [f"![{idx}] = {val}" for idx, val in updates]
                # 生成形如 var' = [ var EXCEPT ![idx1] = val1, ![idx2] = val2 ]
                action_clauses.append(f"{var}' = [ {var} EXCEPT " + ", ".join(except_clauses) + " ]")
                updated_vars.add(var)
        # 其它未更新的变量保持不变
        unchanged_vars = [v for v in var_names if v not in updated_vars]
        if unchanged_vars:
            action_clauses.append("UNCHANGED << " + ", ".join(unchanged_vars) + " >>")
        # 将条件和动作合成为一个转移分支
        branch = "(" + cond_tla + " /\\ " + " /\\ ".join(action_clauses) + ")"
        transition_branches.append(branch)
    # 合并所有分支为 Next 操作
    if transition_branches:
        if len(transition_branches) == 1:
            lines.append("Next == " + transition_branches[0])
        else:
            lines.append("Next ==")
            # 多个分支时，每个用 \\/ 表示非确定性选择
            for i, branch in enumerate(transition_branches):
                prefix = "    \\/"  # 缩进以提高可读性
                lines.append(prefix + " " + branch)

    # 不变性(Invariants)定义，将 YAML 中给出的不变性表达式定义为 TLA+ 算子
    invariant_names = []
    for inv in data.get('invariants', []):
        name = inv.get('name', 'Inv')
        expr = str(inv.get('expr', 'TRUE'))
        expr_tla = expr.replace("&&", "/\\").replace("||", "\\/").replace("==", "=")
        expr_tla = expr_tla.replace("true", "TRUE").replace("false", "FALSE")
        # 确保不变性算子名称是有效标识符
        inv_name = "Inv_" + "".join(ch if ch.isalnum() or ch == '_' else '_' for ch in name)
        if inv_name[0].isdigit():
            inv_name = "_" + inv_name
        lines.append(f"{inv_name} == {expr_tla}")
        invariant_names.append(inv_name)

    # 结束模块
    lines.append("====")

    # 将生成的 TLA+ 内容写入文件
    tla_filename = f"{module_name}.tla"
    cfg_filename = f"{module_name}.cfg"
    with open(tla_filename, 'w') as f:
        f.write("\n".join(lines))

    # 生成 TLC 配置内容 (.cfg)
    cfg_lines = []
    # 常量赋值（如设置进程数量或集合）
    if constants:
        cfg_lines.append("CONSTANTS")
        for const_name, const_val in constants.items():
            # 根据类型格式化常量值（数字、布尔、字符串或集合）
            if isinstance(const_val, bool):
                val_str = "TRUE" if const_val else "FALSE"
            elif isinstance(const_val, (int, float)):
                val_str = str(const_val)
            elif isinstance(const_val, str):
                # 字符串常量加引号
                val_str = f'"{const_val}"'
            elif isinstance(const_val, list):
                # 列表常量作为集合
                elems = [("TRUE" if x else "FALSE") if isinstance(x, bool) 
                         else (f'"{x}"' if isinstance(x, str) else str(x)) 
                         for x in const_val]
                val_str = "{ " + ", ".join(elems) + " }"
            else:
                val_str = str(const_val)
            cfg_lines.append(f"    {const_name} = {val_str}")
    # 指定初始状态和下一步关系
    cfg_lines.append(f"INIT Init")
    cfg_lines.append(f"NEXT Next")
    # 指定需要检查的不变性 (引用前面 TLA+ 中定义的算子)
    if invariant_names:
        # 多个 invariant 名称用逗号分隔列出
        cfg_lines.append("INVARIANT " + ", ".join(invariant_names))
    with open(cfg_filename, 'w') as f:
        f.write("\n".join(cfg_lines))

    return tla_filename, cfg_filename