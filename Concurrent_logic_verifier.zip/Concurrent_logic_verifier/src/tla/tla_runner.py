# src/python/tla/tla_runner.py

import os
import subprocess
from pathlib import Path

def run_tlc(tla_file: str, cfg_file: str = None, jar_path: str = None):
    """
    调用 TLC 对指定的 TLA+ 规范进行模型检查。

    参数:
      tla_file: .tla 文件路径
      cfg_file: .cfg 文件路径，可选
      jar_path: TLC 工具的 jar 包路径，可选
    返回:
      (stdout: str, stderr: str, exit_code: int)
    """
    # 1. 参数优先，其次环境变量，其次项目根目录下的 tla2tools.jar
    env_jar = os.getenv("TLA_TOOLS_JAR")
    project_root = Path(__file__).parents[2]  # 回到 src/ 上级两级即项目根
    default_jar = project_root / "tla2tools.jar"
    jar = Path(jar_path or env_jar or default_jar).expanduser().resolve()

    print(f"[DEBUG] 使用的 TLC jar 路径: {jar}")

    if not jar.is_file():
        raise FileNotFoundError(f"TLA+ 工具 jar 未找到: {jar}")

    # 构造命令：绝不经过 shell，避免路径被截断或注释
    cmd = ["java", "-jar", str(jar)]
    if cfg_file:
        cmd += ["-config", str(Path(cfg_file).resolve())]
    cmd.append(str(Path(tla_file).resolve()))

    # 运行 TLC
    proc = subprocess.run(cmd,
                          stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,
                          text=True)
    return proc.stdout, proc.stderr, proc.returncode