# src/parser.py
import yaml

def parse_model(yaml_path):
    """解析 YAML 配置文件，返回模型数据字典。"""
    with open(yaml_path, 'r', encoding='utf-8') as f:
        model = yaml.safe_load(f)  # 安全加载 YAML 内容
    if 'variables' not in model or 'processes' not in model:
        raise ValueError("YAML 文件缺少 'variables' 或 'processes' 部分")
    return model