# src/tla_generator.py
def generate_tla_module(model, spec_name):
    """根据模型数据生成 TLA+ 规格字符串。"""
    lines = []
    lines.append(f"---- MODULE {spec_name} ----")
    lines.append("EXTENDS TLC\n")

    # 变量声明
    vars_list = list(model.get('variables', {}).keys())
    if vars_list:
        lines.append("VARIABLES " + ", ".join(vars_list) + "\n")

    # 初始条件 Init
    init_conditions = []
    for var, val in model.get('variables', {}).items():
        # 确保字符串值正确加上双引号
        if isinstance(val, str):
            val_expr = f"\"{val}\""
        else:
            val_expr = str(val)
        init_conditions.append(f"{var} = {val_expr}")
    if init_conditions:
        lines.append("Init ==")
        lines.append("    " + init_conditions[0])
        for cond in init_conditions[1:]:
            lines.append("    /\\ " + cond)
        lines.append("")  # 空行

    # 下一步关系 Next
    transition_forms = []
    for proc_name, proc in model.get('processes', {}).items():
        for trans in proc.get('transitions', []):
            guard = trans.get('precondition', "")  # 前置条件
            effect = trans.get('effect', {})       # 后置效果
            guard_expr = guard.replace("&&", " /\\ ").replace("||", " \\/ ")
            effects_exprs = [f"{var}' = {new_val}" for var, new_val in effect.items()]
            effect_expr = " /\\ ".join(effects_exprs)
            transition_forms.append(f"({guard_expr}) /\\ {effect_expr}")
    if transition_forms:
        lines.append("Next ==")
        lines.append("    " + "(" + transition_forms[0] + ")")
        for trans_expr in transition_forms[1:]:
            lines.append("    \\/ (" + trans_expr + ")")
        lines.append("")  # 空行

    lines.append("====")  # 模块结尾
    return "\n".join(lines)

def write_tla_and_cfg(model, yaml_path):
    """生成 TLA+ 模块和 .cfg 配置文件，并写入输出目录。"""
    spec_name = yaml_path.split('/')[-1].split('.')[0]  # 获取文件名（不带扩展名）
    tla_content = generate_tla_module(model, spec_name)
    
    # 写入 .tla 文件
    tla_path = f"output/{spec_name}.tla"
    with open(tla_path, 'w', encoding='utf-8') as f_tla:
        f_tla.write(tla_content)
    
    # 写入 .cfg 文件
    cfg_path = f"output/{spec_name}.cfg"
    with open(cfg_path, 'w', encoding='utf-8') as f_cfg:
        f_cfg.write(f"INIT Init\nNEXT Next\n")
    
    return spec_name, tla_path, cfg_path