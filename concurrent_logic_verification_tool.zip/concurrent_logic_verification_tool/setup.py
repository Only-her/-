# setup.py
from setuptools import setup, find_packages

setup(
    name="concurrent_logic",
    version="0.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "pyyaml",
        "graphviz",
        "jsonschema",
        "jinja2"
    ],
    include_package_data=True  # 确保包含所有子模块文件
)