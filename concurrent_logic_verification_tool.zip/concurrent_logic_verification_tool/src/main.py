# src/main.py
import argparse
import logging
from pathlib import Path
from typing import Dict, Any

from src.logic_description.parser import parse_concurrent_logic
from src.element_extraction.shared_vars import extract_shared_variables
from src.element_extraction.sync_primitives import detect_sync_primitives
from src.reasoning.data_race import detect_data_races
from src.reasoning.deadlock import detect_deadlocks
from src.verification.tla.generator import generate_tla_spec
from src.verification.tla.runner import run_tlc
from src.verification.tla.parser import TlcOutputParser
from src.verification.coq.generator import generate_coq_model
from src.verification.coq.verifier import compile_coq_model, run_coq_verification
from src.verification.visualization.reporter import generate_html_report
from src.logic_description.parser import ConcurrentLogic


# 配置日志输出
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class SimpleResult:
    """简单的结果包装类，用于将验证工具返回的字典转换为具有属性的对象"""
    def __init__(self, result_dict):
        self.is_valid = result_dict.get("success", False)
        stderr = result_dict.get("stderr", "")
        # 将stderr按行拆分成错误列表，若为空则设为空列表
        self.errors = stderr.splitlines() if stderr else []
        self.raw_output = result_dict.get("stdout", "")
        self.counterexample = result_dict.get("counterexample", None)


class CombinedResult:
    """将TLA+和Coq两种验证结果合并"""
    def __init__(self, tla_result: SimpleResult, coq_result: SimpleResult):
        self.tla = tla_result
        self.coq = coq_result
        self.is_valid = tla_result.is_valid and coq_result.is_valid
        self.errors = tla_result.errors + coq_result.errors
        self.raw_output = (
            "========== TLA+ 输出 ==========\n" +
            tla_result.raw_output +
            "\n\n========== Coq 输出 ==========\n" +
            coq_result.raw_output
        )
        # 如任一工具返回反例，则保存之
        self.counterexample = tla_result.counterexample or coq_result.counterexample


def main():
    parser = argparse.ArgumentParser(description="并发逻辑形式化验证工具 - 同时使用 TLA+ 和 Coq")
    parser.add_argument("--input", required=True, help="DSL输入文件路径（YAML格式）")
    parser.add_argument("--report", default="report.html", help="生成的HTML验证报告输出路径")
    parser.add_argument("--graph", default="state_graph", help="状态图输出路径（不含后缀）")
    args = parser.parse_args()

    # 1. 解析DSL文件，生成领域模型
    try:
        from src.logic_description.parser import parse_concurrent_logic
        logging.info(f"开始解析DSL文件：{args.input}")
        logic = parse_concurrent_logic(args.input)
        logging.info("DSL解析成功")
    except Exception as e:
        logging.error(f"DSL解析失败: {e}")
        return

    # 2. 提取要素
    from src.element_extraction.core import extract_elements
    logging.info("开始提取并发要素")
    elements = extract_elements(logic)
    logging.info("要素提取完成")

    # 3. 并发问题推理分析
    from src.reasoning.core import analyze_concurrency_issues
    logging.info("进行并发问题推理分析")
    analysis_result = analyze_concurrency_issues(logic, elements)
    print("并发问题分析结果：")
    for key, issues in analysis_result.items():
        print(f"{key}:")
        for issue in issues:
            print(issue)

    # 4. 形式化验证：同时使用 TLA+ 和 Coq

    # 4.1 TLA+验证
    from src.verification.tla.generator import generate_tla_spec
    from src.verification.tla.runner import run_tlc
    logging.info("生成TLA+规范文件")
    tla_spec = generate_tla_spec(logic)
    logging.info("生成的TLA+规范：")
    print(tla_spec)
    logging.info("执行TLC模型检查")
    tla_result_dict = run_tlc(spec_path="specs/generated.tla")
    tla_result = SimpleResult(tla_result_dict)

    # 4.2 Coq验证
    from src.verification.coq.generator import generate_coq_model
    from src.verification.coq.verifier import compile_coq_model, run_coq_verification
    logging.info("生成Coq模型")
    coq_code = generate_coq_model(logic)
    compile_coq_model(coq_code)
    logging.info("执行Coq验证")
    coq_result_dict = run_coq_verification(coq_file="outputs/coq_model.v")
    coq_result = SimpleResult(coq_result_dict)

    # 4.3 合并验证结果
    combined_result = CombinedResult(tla_result, coq_result)
    print("形式化验证结果（合并）：")
    print(f"验证通过: {combined_result.is_valid}")
    if combined_result.errors:
        print("错误信息:")
        for err in combined_result.errors:
            print(err)
    if combined_result.raw_output:
        print("原始输出:")
        print(combined_result.raw_output)

    # 5. 生成HTML验证报告
    from src.verification.visualization.reporter import generate_html_report
    logging.info("生成HTML验证报告")
    html = generate_html_report(result=combined_result, output_path=args.report)
    logging.info(f"验证报告已生成: {args.report}")

    # 6. 生成状态图（此处使用固定示例，后续可改为动态生成）
    from src.verification.visualization.grapher import generate_state_graph
    logging.info("生成状态转换图")
    generate_state_graph(args.graph)
    logging.info(f"状态图已生成: {args.graph}")

if __name__ == "__main__":
    main()