# src/verification/visualization/grapher.py
from graphviz import Digraph

def generate_state_graph(output_path: str) -> None:
    """生成状态转换图"""
    dot = Digraph(comment='State Transitions')
    dot.node('Init')
    dot.node('State1')
    dot.edge('Init', 'State1')
    dot.render(output_path, view=True)