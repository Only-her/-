# src/verification/visualization/reporter.py
from jinja2 import Template

def generate_html_report(result: dict, output_path: str) -> str:
    """生成HTML验证报告"""
    template = Template("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>验证报告 - {{ '通过' if result.is_valid else '失败' }}</title>
        <style>
            .success { color: green; }
            .error { color: red; }
            pre { background: #f0f0f0; padding: 10px; }
        </style>
    </head>
    <body>
        <h1>验证结果: <span class="{{ 'success' if result.is_valid else 'error' }}">{{ '通过' if result.is_valid else '失败' }}</span></h1>
        {% if result.errors %}
        <h2>检测到的问题:</h2>
        <ul>
            {% for err in result.errors %}
            <li class="error">{{ err }}</li>
            {% endfor %}
        </ul>
        {% endif %}
        {% if result.raw_output %}
        <pre>{{ result.raw_output }}</pre>
        {% endif %}
    </body>
    </html>
    """)
    html = template.render(result=result)
    with open(output_path, 'w') as f:
        f.write(html)
    return html