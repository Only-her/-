# src/verification/tla/tla_generator.py
from typing import Dict, List
from src.logic_description.logic_model import ConcurrentLogic

def generate_tla_spec(logic: ConcurrentLogic, output_path: str = "specs/generated.tla") -> str:
    """
    生成TLA+规范文件
    :param logic: 并发逻辑描述
    :param output_path: 输出文件路径
    :return: 生成的TLA+规范内容
    """
    # 定义TLA+模板
    spec_template = f"""
---- MODULE GeneratedConcurrentLogic ----
EXTENDS Naturals, Sequences, TLC

(* 定义进程和共享变量 *)
VARIABLES {", ".join(logic.shared_vars)}

(* 定义进程行为 *)
{_generate_process_actions(logic)}

(* 初始状态定义 *)
Init ==
    /\ {_generate_initial_conditions(logic)}

(* 状态转移定义 *)
Next ==
    \/ {_generate_transitions(logic)}

(* 安全性条件 *)
Safety ==
    {_generate_safety_conditions(logic)}

====
"""
    # 写入文件
    with open(output_path, "w") as f:
        f.write(spec_template)
    
    return spec_template

def _generate_process_actions(logic: ConcurrentLogic) -> str:
    """生成进程行为定义"""
    actions = []
    for process in logic.processes:
        action_seq = "\n    ".join([
            f'{"Read" if a.type == "read" else "Write"}({a.target})'
            for a in process.actions
        ])
        actions.append(f"Process{process.name} ==\n    {action_seq}")
    return "\n\n".join(actions)

def _generate_initial_conditions(logic: ConcurrentLogic) -> str:
    """生成初始状态条件"""
    return " /\ ".join([f"{var} = 0" for var in logic.shared_vars])

def _generate_transitions(logic: ConcurrentLogic) -> str:
    """生成状态转移条件"""
    return " \/ ".join([f"Process{process.name}" for process in logic.processes])

def _generate_safety_conditions(logic: ConcurrentLogic) -> str:
    """生成安全性条件"""
    return " /\ ".join([
        f"\\A p1, p2 \\in Processes: p1 /= p2 => {var}_p1 = {var}_p2"
        for var in logic.shared_vars
    ])