# src/verification/tla/__init__.py
from .runner import run_tlc
from .generator import generate_tla_spec

__all__ = ["run_tlc", "generate_tla_spec"]