# src/verification/tla/runner.py
import subprocess
from pathlib import Path
import logging

def run_tlc(spec_path: str) -> dict:
    """运行TLC模型检查器"""
    try:
        # 确保spec文件存在
        if not Path(spec_path).exists():
            raise FileNotFoundError(f"TLA+规范文件不存在: {spec_path}")
        
        # 运行TLC命令
        result = subprocess.run(
            ["tlc", "-cleanup", spec_path],
            capture_output=True,
            text=True,
            timeout=30  # 设置超时
        )
        
        # 解析结果
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "counterexample": None  # 需要后续实现解析
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "stderr": "TLC执行超时"
        }
    except Exception as e:
        return {
            "success": False,
            "stderr": str(e)
        }