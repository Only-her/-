import re

from verification.core import VerificationResult

class TlcOutputParser:
    def parse(self, output: str) -> VerificationResult:
        # 检测错误类型
        errors = []
        if "Error: Invariant" in output:
            errors.append("安全性条件违反")
        if "Deadlock" in output:
            errors.append("检测到死锁")
        
        # 提取反例路径
        counterexample = None
        trace_match = re.search(r"Error: (.*?)\n(.*?)(?=\n\n|\Z)", output, re.DOTALL)
        if trace_match:
            counterexample = trace_match.group(0)
        
        return VerificationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            raw_output=output,
            counterexample=counterexample
        )