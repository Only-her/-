# src/verification/__init__.py
"""
形式化验证模块入口文件
"""
from .tla.generator import generate_tla_spec
from .tla.runner import run_tlc
from .visualization.reporter import generate_html_report
from .visualization.grapher import generate_state_graph