import subprocess
from pathlib import Path

def run_coq_verification(coq_file: str) -> dict:
    """执行Coq证明并返回结果"""
    try:
        result = subprocess.run(
            ["coqc", coq_file],
            capture_output=True,
            text=True,
            timeout=60  # 设置超时时间
        )
        return {
            "success": "Proof completed" in result.stdout,
            "stdout": result.stdout,
            "stderr": result.stderr
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Timeout"}

def compile_coq_model(coq_code: str, output_path: str = "outputs/coq_model.v") -> None:
    """将生成的Coq代码保存到文件"""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        f.write(coq_code)