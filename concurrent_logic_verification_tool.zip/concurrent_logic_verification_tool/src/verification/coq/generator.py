from typing import Dict, List
from src.logic_description.logic_model import ConcurrentLogic

def generate_coq_model(logic: ConcurrentLogic) -> str:
    """将并发逻辑转换为Coq代码"""
    coq_template = f"""
Require Import Coq.Lists.List.
Import ListNotations.

(* 定义共享变量类型 *)
Inductive SharedVar :=
{_generate_shared_vars(logic.shared_vars)}.

(* 定义锁类型 *)
Inductive Lock :=
{_generate_locks(logic.locks)}.

(* 定义进程操作 *)
Inductive Action :=
{_generate_actions(logic.processes)}.

(* 定义初始状态 *)
Definition initial_state : list (SharedVar * nat) :=
{_generate_initial_state(logic.shared_vars)}.

(* 定义安全性定理：无数据竞争 *)
Theorem no_data_race: forall (a: Action),
  ~ (exists var, In var [{', '.join(logic.shared_vars)}] /\\
                 concurrent_access a var).
Proof.
  (* 自动化证明策略 *)
  auto with concurrency.
Qed.
"""
    return coq_template

def _generate_shared_vars(vars: List[str]) -> str:
    return "\n| ".join([f"| {var} : SharedVar" for var in vars])

def _generate_locks(locks: List[str]) -> str:
    return "\n| ".join([f"| {lock} : Lock" for lock in locks])

def _generate_actions(processes: List) -> str:
    actions = []
    for p in processes:
        for action in p.actions:
            if action.type in ["lock", "unlock"]:
                actions.append(f"| {action.type}_{action.target} : Action")
            else:
                actions.append(f"| {action.type}_{action.target} : Action")
    return "\n".join(actions)

def _generate_initial_state(vars: List[str]) -> str:
    return "[" + "; ".join([f"({var}, 0)" for var in vars]) + "]"