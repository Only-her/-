from abc import ABC, abstractmethod
from typing import Dict, Any
from pathlib import Path

class VerificationTool(ABC):
    """形式化验证工具抽象基类"""
    
    @abstractmethod
    def generate_model(self, logic_data: Dict, output_dir: str) -> str:
        """生成形式化模型文件"""
        pass
    
    @abstractmethod
    def run_verification(self, model_path: str) -> Dict[str, Any]:
        """执行验证并返回结果"""
        pass

class VerificationResult:
    """统一验证结果类"""
    def __init__(self, is_valid: bool, errors: list, raw_output: str, counterexample: str = None):
        self.is_valid = is_valid
        self.errors = errors
        self.raw_output = raw_output
        self.counterexample = counterexample