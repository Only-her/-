# src/element_extraction/core.py
from typing import Dict, Any
from .shared_vars import extract_shared_variables
from .operation_order import extract_operation_sequences
from .sync_primitives import detect_sync_primitives
from src.logic_description.logic_model import ConcurrentLogic

def extract_elements(logic: ConcurrentLogic) -> Dict[str, Any]:
    """
    要素提取总入口
    返回结构:
    {
        "shared_variables": {变量: 进程列表},
        "operation_sequences": {进程: 操作序列},
        "sync_primitives": {锁: 操作记录}
    }
    """
    return {
        "shared_variables": extract_shared_variables(logic),
        "operation_sequences": extract_operation_sequences(logic),
        "sync_primitives": detect_sync_primitives(logic)
    }