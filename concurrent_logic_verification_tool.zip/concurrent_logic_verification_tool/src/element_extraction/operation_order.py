# src/element_extraction/operation_order.py
from typing import Dict, List
from src.logic_description.logic_model import ConcurrentLogic, Process

def extract_operation_sequences(logic: ConcurrentLogic) -> Dict[str, List[dict]]:
    """
    提取每个进程的操作时序
    返回格式: {进程名: [带顺序的操作记录]}
    """
    sequences = {}
    
    for process in logic.processes:
        sequence = []
        for idx, action in enumerate(process.actions):
            sequence.append({
                "order": idx + 1,
                "type": action.type,
                "target": action.target,
                "is_sync": action.type in ["lock", "unlock"]
            })
        sequences[process.name] = sequence
    
    return sequences