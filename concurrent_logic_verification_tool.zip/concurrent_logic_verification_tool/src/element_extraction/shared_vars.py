# src/element_extraction/shared_vars.py
from typing import Dict, List, Set
from collections import defaultdict
from src.logic_description.logic_model import ConcurrentLogic, Action

def extract_shared_variables(logic: ConcurrentLogic) -> Dict[str, List[str]]:
    """
    提取被多个进程访问的共享变量
    返回格式: {变量名: [访问该变量的进程列表]}
    """
    var_access_map = defaultdict(set)
    
    for process in logic.processes:
        for action in process.actions:
            if action.type in ["read", "write"]:
                var_access_map[action.target].add(process.name)
    
    # 过滤出被多个进程访问的变量
    return {
        var: list(processes)
        for var, processes in var_access_map.items()
        if len(processes) > 1
    }