# src/element_extraction/sync_primitives.py
from typing import Dict, List, Tuple
from collections import defaultdict
from src.logic_description.logic_model import ConcurrentLogic

def detect_sync_primitives(logic: ConcurrentLogic) -> Dict[str, List[Tuple]]:
    """
    检测同步原语（锁）的使用模式
    返回格式: {锁名称: [(进程名, 操作类型, 顺序)]}
    """
    lock_operations = defaultdict(list)
    
    for process in logic.processes:
        lock_stack = []  # 用于检测嵌套锁
        for action in process.actions:
            if action.type in ["lock", "unlock"]:
                # 记录操作上下文
                lock_operations[action.target].append((
                    process.name,
                    action.type,
                    action.order,
                    len(lock_stack)  # 当前锁嵌套深度
                ))
                
                # 更新锁栈状态
                if action.type == "lock":
                    lock_stack.append(action.target)
                elif lock_stack:
                    lock_stack.pop()
    
    return {
        lock: sorted(ops, key=lambda x: x[2])  # 按操作顺序排序
        for lock, ops in lock_operations.items()
    }