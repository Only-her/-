# src/logic_description/__init__.py
"""
并发逻辑描述模块入口文件
"""
from .parser import parse_concurrent_logic
from .logic_model import Process, Action