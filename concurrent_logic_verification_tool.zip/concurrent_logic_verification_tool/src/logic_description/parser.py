# src/logic_description/parser.py
import yaml
import logging
from pathlib import Path
from typing import Dict, Any
from .logic_model import Process, Action, ConcurrentLogic
from .dsl_validator import validate_dsl_structure

logger = logging.getLogger(__name__)

def parse_concurrent_logic(file_path: str) -> ConcurrentLogic:
    """
    解析并发逻辑描述文件的主函数
    """
    try:
        # 读取并验证文件基础信息
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"输入文件 {file_path} 不存在")
        if path.suffix not in [".yml", ".yaml"]:
            raise ValueError("仅支持YAML格式输入文件")

        # 解析YAML内容
        with open(file_path, 'r') as f:
            raw_data = yaml.safe_load(f)
        
        # 验证DSL结构
        validate_dsl_structure(raw_data)  # 此处可能抛出jsonschema.ValidationError
        
        # 转换为领域模型
        return _build_logic_model(raw_data)
    
    except (yaml.YAMLError, FileNotFoundError, ValueError) as e:
        logging.error(f"并发逻辑解析失败: {str(e)}")
        raise

def _build_logic_model(raw_data: Dict[str, Any]) -> ConcurrentLogic:
    """
    将原始数据转换为领域模型
    """
    processes = []
    for p in raw_data["processes"]:
        actions = [
            Action(
                type=action["type"],
                target=action["target"],
                value=action.get("value"),
                order=idx
            )
            for idx, action in enumerate(p["actions"])
        ]
        processes.append(Process(
            name=p["name"],
            actions=actions,
            is_daemon=p.get("is_daemon", False)
        ))
    
    return ConcurrentLogic(
        processes=processes,
        shared_vars=raw_data.get("shared_vars", []),
        locks=raw_data.get("locks", [])
    )