# src/logic_description/dsl_validator.py
from typing import Dict, Any
import jsonschema
from jsonschema import validate

# DSL结构验证规则
DSL_SCHEMA = {
    "type": "object",
    "required": ["processes"],
    "properties": {
        "processes": {
            "type": "array",
            "minItems": 2,
            "items": {
                "type": "object",
                "required": ["name", "actions"],
                "properties": {
                    "name": {"type": "string"},
                    "is_daemon": {"type": "boolean"},
                    "actions": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["type", "target"],
                            "properties": {
                                "type": {
                                    "type": "string",
                                    "enum": ["read", "write", "lock", "unlock", "fork", "join"]
                                },
                                "target": {"type": "string"},
                                "value": {"type": "string"}
                            }
                        }
                    }
                }
            }
        },
        "shared_vars": {
            "type": "array",
            "items": {"type": "string"}
        },
        "locks": {
            "type": "array",
            "items": {"type": "string"}
        }
    }
}

def validate_dsl_structure(data: Dict[str, Any]):
    """
    验证输入的DSL结构是否符合规范
    """
    try:
        validate(instance=data, schema=DSL_SCHEMA)
    except jsonschema.ValidationError as e:
        error_path = "->".join(map(str, e.absolute_path))
        e.message = f"DSL结构验证失败: 字段 [{error_path}] {e.message}"  # 增强错误信息
        raise  # 直接抛出原始的ValidationError，不转换为ValueError