# src/logic_description/logic_model.py
from dataclasses import dataclass
from typing import List, Literal

@dataclass
class Action:
    """
    表示并发操作的数据类
    """
    type: Literal["read", "write", "lock", "unlock", "fork", "join"]
    target: str  # 共享变量名或锁名称
    value: str = None  # 仅写操作需要
    order: int = 0  # 操作执行顺序

@dataclass
class Process:
    """
    表示并发进程/线程的数据类
    """
    name: str
    actions: List[Action]
    is_daemon: bool = False  # 是否守护进程

@dataclass
class ConcurrentLogic:
    """
    完整并发逻辑描述数据结构
    """
    processes: List[Process]
    shared_vars: List[str]
    locks: List[str] = None

