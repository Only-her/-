# src/reasoning/atomicity.py
from typing import List, Dict
from src.logic_description.logic_model import ConcurrentLogic


def check_atomicity_violations(logic: ConcurrentLogic, elements: Dict) -> List[Dict]:
    """
    检测原子性违反问题
    返回格式: [
        {
            "type": "atomicity",
            "variable": "var_name",
            "critical_sections": [
                {"process": "p1", "operations": [op1, op2]},
               
            ]
        }
    ]
    """
    violations = []
    
    for var in elements["shared_variables"]:
        # 查找相关原子操作组
        atomic_groups = _find_atomic_groups(var, logic)
        
        # 检查是否存在非原子访问
        if len(atomic_groups) > 1:
            violations.append({
                "type": "atomicity",
                "variable": var,
                "critical_sections": atomic_groups
            })
    
    return violations

def _find_atomic_groups(var: str, logic: ConcurrentLogic) -> List[Dict]:
    """识别变量的原子操作组"""
    groups = []
    current_group = []
    in_critical_section = False
    
    for process in logic.processes:
        for action in process.actions:
            if action.target == var:
                if action.type == "lock":
                    in_critical_section = True
                    current_group = []
                elif action.type == "unlock":
                    in_critical_section = False
                    if current_group:
                        groups.append({
                            "process": process.name,
                            "operations": current_group
                        })
                elif in_critical_section:
                    current_group.append(action)
    
    return groups