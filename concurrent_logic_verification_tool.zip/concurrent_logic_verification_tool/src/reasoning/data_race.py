# src/reasoning/data_race.py
from typing import Dict, List
from src.logic_description.logic_model import ConcurrentLogic, Process
from src.logic_description.logic_model import ConcurrentLogic  # 新增导入


def detect_data_races(logic: ConcurrentLogic, elements: Dict) -> List[Dict]:
    """
    检测数据竞争问题
    返回格式: [
        {
            "type": "data_race",
            "variable": "var_name",
            "processes": ["p1", "p2"],
            "operations": [op1, op2],
            "protected_by": []  # 保护该变量的锁列表
        }
    ]
    """
    races = []
    
    # 获取共享变量和同步信息
    shared_vars = elements["shared_variables"]
    sync_ops = elements["sync_primitives"]
    
    for var, processes in shared_vars.items():
        # 检查写操作是否存在
        write_ops = [
            op for p in logic.processes 
            for op in p.actions 
            if op.target == var and op.type == "write"
        ]
        if not write_ops:
            continue
        
        # 检查同步保护
        protecting_locks = _find_protecting_locks(var, logic, sync_ops)
        
        # 如果存在未保护的并发访问
        if not protecting_locks and len(processes) >= 2:
            conflicting_ops = _find_conflicting_operations(var, logic)
            races.append({
                "type": "data_race",
                "variable": var,
                "processes": processes,
                "operations": conflicting_ops,
                "protected_by": []
            })
    
    return races

def _find_protecting_locks(var: str, logic: ConcurrentLogic, sync_ops: Dict) -> List[str]:
    """查找保护该变量的锁"""
    protecting_locks = []
    for lock, ops in sync_ops.items():
        for process in logic.processes:
            # 检查变量访问是否在锁保护范围内
            if _is_var_protected(var, process, lock):
                protecting_locks.append(lock)
    return list(set(protecting_locks))

def _find_conflicting_operations(var: str, logic: ConcurrentLogic) -> List[Dict]:
    """查找对同一变量的冲突操作"""
    conflicts = []
    for process in logic.processes:
        for action in process.actions:
            if action.target == var and action.type in ["read", "write"]:
                conflicts.append({
                    "process": process.name,
                    "operation": action.type,
                    "order": action.order
                })
    return conflicts

def _is_var_protected(var: str, process: Process, lock: str) -> bool:
    """判断变量访问是否被指定锁保护"""
    current_lock_state = False
    for action in process.actions:
        if action.target == lock:
            current_lock_state = (action.type == "lock")
        elif action.target == var and current_lock_state:
            return True
    return False