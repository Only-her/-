# src/reasoning/deadlock.py
from typing import List, Dict
from collections import defaultdict
from src.logic_description.logic_model import ConcurrentLogic  # 新增导入

def detect_deadlocks(logic: ConcurrentLogic, elements: Dict) -> List[Dict]:
    """
    """
    lock_order_map = defaultdict(list)
    
    for process in logic.processes:
        acquired_locks = []
        # 仅记录完整的锁获取顺序
        for action in process.actions:
            if action.type == "lock":
                acquired_locks.append(action.target)
            elif action.type == "unlock" and acquired_locks:
                acquired_locks.pop()
        
        # 记录进程的完整锁顺序（去重）
        if len(acquired_locks) >= 2:
            lock_order = tuple(acquired_locks)
            if lock_order not in lock_order_map:
                lock_order_map[lock_order] = []
            lock_order_map[lock_order].append(process.name)
    
    return _find_lock_order_violations(lock_order_map)

def _find_lock_order_violations(lock_order_map: Dict) -> List[Dict]:
    """
    """
    violations = []
    orders = list(lock_order_map.keys())
    
    for i in range(len(orders)):
        for j in range(i+1, len(orders)):
            if _is_reversed(orders[i], orders[j]):
                violations.append({
                    "type": "deadlock",
                    "chains": [
                        {"processes": lock_order_map[orders[i]], "locks": orders[i]},
                        {"processes": lock_order_map[orders[j]], "locks": orders[j]}
                    ]
                })
    return violations

def _is_reversed(seq1: tuple, seq2: tuple) -> bool:
    """严格检测锁顺序反转"""
    # 示例：seq1=(A,B), seq2=(B,A)
    if len(seq1) < 2 or len(seq2) < 2:
        return False
    
    # 检查是否存在至少一对锁顺序相反
    for i in range(len(seq1)):
        for j in range(len(seq2)):
            if seq1[i] == seq2[j] and i != j:
                # 查找后续锁是否形成反向对
                for x in seq1[i+1:]:
                    if x in seq2[:j]:
                        return True
    return False