# src/reasoning/core.py
from typing import Dict, List
from .data_race import detect_data_races
from .deadlock import detect_deadlocks
from .atomicity import check_atomicity_violations
from src.logic_description.parser import ConcurrentLogic

def analyze_concurrency_issues(logic: ConcurrentLogic, elements: Dict) -> Dict[str, List]:
    """
    并发问题分析总入口
    返回结构:
    {
        "data_races": [...],
        "deadlocks": [...],
        "atomicity_violations": [...]
    }
    """
    return {
        "data_races": detect_data_races(logic, elements),
        "deadlocks": detect_deadlocks(logic, elements),
        "atomicity_violations": check_atomicity_violations(logic, elements)
    }