from collections import defaultdict

def analyze_concurrency_operations(ops: list) -> dict:
    """分析并发操作类型及其上下文"""
    concurrency_data = defaultdict(list)
    for op in ops:
        if op["type"] == "lock_operation":
            lock_type = "spinlock" if "spin" in op["name"] else "mutex"
            concurrency_data["locks"].append({
                "name": op["name"],
                "type": lock_type,
                "location": op["location"]
            })
        elif op["type"] == "atomic_operation":
            concurrency_data["atomics"].append(op)
    return concurrency_data