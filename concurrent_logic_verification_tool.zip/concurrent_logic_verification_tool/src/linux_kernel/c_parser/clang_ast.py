import clang.cindex
from clang.cindex import CursorKind, TranslationUnit

def parse_kernel_file(file_path: str) -> dict:
    """解析内核C文件，提取锁、原子操作等并发原语"""
    index = clang.cindex.Index.create()
    tu = index.parse(
        file_path,
        args=[
            "-I/usr/src/linux-headers-$(uname -r)/include",
            "-D__KERNEL__",
            "-D__GNUC__"
        ]
    )
    concurrency_ops = {"locks": [], "atomics": []}

    def _walk(node):
        # 检测锁操作（spin_lock, mutex_lock等）
        if node.kind == CursorKind.CALL_EXPR:
            func_name = node.spelling or node.displayname
            if "_lock" in func_name or "_unlock" in func_name:
                concurrency_ops["locks"].append({
                    "type": "lock",
                    "name": func_name,
                    "location": f"{node.location.file.name}:{node.location.line}"
                })
            elif "atomic_" in func_name:
                concurrency_ops["atomics"].append({
                    "type": "atomic",
                    "name": func_name,
                    "location": f"{node.location.file.name}:{node.location.line}"
                })
        # 递归遍历所有子节点
        for child in node.get_children():
            _walk(child)

    _walk(tu.cursor)
    return concurrency_ops