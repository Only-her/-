def generate_tla_spec(concurrency_data: dict) -> str:
    """将并发操作映射为TLA+规范"""
    locks = [op["name"] for op in concurrency_data["locks"]]
    atomics = [op["name"] for op in concurrency_data["atomics"]]
    
    tla_template = f"""
---- MODULE KernelConcurrency ----
EXTENDS Naturals, TLC

(* 定义锁和原子变量 *)
VARIABLES {", ".join(locks + atomics)}

(* 锁操作行为 *)
LockActions ==
    {" \/ ".join([f'<<{lock}>>' for lock in locks])}

(* 原子操作行为 *)
AtomicActions ==
    {" \/ ".join([f'<<{atomic}>>' for atomic in atomics])}

(* 初始状态 *)
Init ==
    /\ {' /\ '.join([f'{var} = 0' for var in locks + atomics])}

(* 状态转移 *)
Next ==
    /\ LockActions
    /\ AtomicActions

====
    """
    return tla_template