# tests/test_reasoning/test_data_race.py
import unittest
from src.logic_description.logic_model import ConcurrentLogic, Process, Action  # 新增导入
from src.reasoning.data_race import detect_data_races

class TestDataRaceDetection(unittest.TestCase):
    def test_basic_data_race(self):
        logic = ConcurrentLogic(
            processes=[
                Process(name="P1", actions=[
                    Action(type="write", target="var1")
                ]),
                Process(name="P2", actions=[
                    Action(type="write", target="var1")
                ])
            ],
            shared_vars=["var1"]
        )
        elements = {
            "shared_variables": {"var1": ["P1", "P2"]},
            "sync_primitives": {}
        }
        races = detect_data_races(logic, elements)
        self.assertEqual(len(races), 1)

if __name__ == "__main__":
    unittest.main()