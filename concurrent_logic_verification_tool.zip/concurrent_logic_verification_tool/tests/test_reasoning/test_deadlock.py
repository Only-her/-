# tests/test_reasoning/test_deadlock.py
import unittest
from src.logic_description.logic_model import ConcurrentLogic, Process, Action
from src.reasoning.deadlock import detect_deadlocks

class TestDeadlockDetection(unittest.TestCase):
    def test_lock_order_violation(self):
        logic = ConcurrentLogic(
            processes=[
                Process(name="P1", actions=[
                    Action(type="lock", target="A"),
                    Action(type="lock", target="B")
                ]),
                Process(name="P2", actions=[
                    Action(type="lock", target="B"),
                    Action(type="lock", target="A")
                ])
            ],
            shared_vars=[],  # 必填参数
            locks=["A", "B"]  # 可选
        )
        elements = {"sync_primitives": {"A": [], "B": []}}
        deadlocks = detect_deadlocks(logic, elements)
        self.assertTrue(any(d["type"] == "deadlock" for d in deadlocks))

if __name__ == "__main__":
    unittest.main()