import unittest
from src.linux_kernel.c_parser.clang_ast import parse_kernel_file

class TestClangAST(unittest.TestCase):
    def test_spinlock_parsing(self):
        ops = parse_kernel_file("data/kernel_samples/spinlock.c")
        self.assertTrue(any(op["name"] == "spin_lock" for op in ops["locks"]))

    def test_atomic_parsing(self):
        ops = parse_kernel_file("data/kernel_samples/atomic.c")
        self.assertTrue(any("atomic_inc" in op["name"] for op in ops["atomics"]))