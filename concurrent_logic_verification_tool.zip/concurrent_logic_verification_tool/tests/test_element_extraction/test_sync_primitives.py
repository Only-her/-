# tests/test_element_extraction/test_sync_primitives.py
import unittest
from src.logic_description.logic_model import ConcurrentLogic, Process, Action
from src.element_extraction.sync_primitives import detect_sync_primitives

class TestSyncPrimitives(unittest.TestCase):
    def test_lock_sequence(self):
        logic = ConcurrentLogic(
            processes=[
                Process(name="P1", actions=[
                    Action(type="lock", target="mutex1", order=1),
                    Action(type="unlock", target="mutex1", order=2),
                    Action(type="lock", target="mutex1", order=3)
                ])
            ],
            shared_vars=[],  # 添加shared_vars参数
            locks=["mutex1"]  # 可选：添加锁列表
        )
        
        result = detect_sync_primitives(logic)
        self.assertEqual(len(result["mutex1"]), 3)
        self.assertEqual(result["mutex1"][0][1], "lock")

if __name__ == "__main__":
    unittest.main()