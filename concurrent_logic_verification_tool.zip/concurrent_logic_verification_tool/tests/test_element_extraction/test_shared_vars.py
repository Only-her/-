# tests/test_element_extraction/test_shared_vars.py
import unittest
from src.logic_description.logic_model import ConcurrentLogic, Process, Action
from src.element_extraction.shared_vars import extract_shared_variables

class TestSharedVars(unittest.TestCase):
    def setUp(self):
        self.sample_logic = ConcurrentLogic(
            processes=[
                Process(name="P1", actions=[
                    Action(type="read", target="varA"),
                    Action(type="write", target="varB")
                ]),
                Process(name="P2", actions=[
                    Action(type="write", target="varA"),
                    Action(type="read", target="varC")
                ])
            ],
            shared_vars=["varA", "varB", "varC"]
        )

    def test_basic_extraction(self):
        result = extract_shared_variables(self.sample_logic)
        self.assertIn("varA", result)
        self.assertNotIn("varB", result)
        self.assertEqual(len(result["varA"]), 2)

if __name__ == "__main__":
    unittest.main()