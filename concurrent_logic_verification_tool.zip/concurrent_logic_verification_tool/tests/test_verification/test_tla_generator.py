# tests/test_verification/test_tla_generator.py
import unittest
from src.logic_description.logic_model import ConcurrentLogic, Process, Action
from src.verification.tla.generator import generate_tla_spec

class TestTlaGenerator(unittest.TestCase):
    def test_generate_tla_spec(self):
        logic = ConcurrentLogic(
            processes=[
                Process(name="P1", actions=[
                    Action(type="write", target="var1")
                ])
            ],
            shared_vars=["var1"]
        )
        spec = generate_tla_spec(logic)
        self.assertIn("VARIABLES var1", spec)

if __name__ == "__main__":
    unittest.main()