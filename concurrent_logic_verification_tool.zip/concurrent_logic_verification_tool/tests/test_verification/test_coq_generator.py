import unittest
from src.logic_description.logic_model import ConcurrentLogic, Process, Action
from src.verification.coq.generator import generate_coq_model

class TestCoqGenerator(unittest.TestCase):
    def test_basic_model(self):
        logic = ConcurrentLogic(
            processes=[
                Process(name="P1", actions=[
                    Action(type="lock", target="mutex"),
                    Action(type="write", target="var1"),
                    Action(type="unlock", target="mutex")
                ])
            ],
            shared_vars=["var1"],
            locks=["mutex"]
        )
        coq_code = generate_coq_model(logic)
        self.assertIn("Theorem no_data_race", coq_code)