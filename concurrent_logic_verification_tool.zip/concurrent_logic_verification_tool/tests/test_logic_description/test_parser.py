import unittest
import jsonschema
import tempfile
from pathlib import Path
from src.logic_description.parser import parse_concurrent_logic

class TestLogicParser(unittest.TestCase):
    SAMPLE_FILE = str(Path(__file__).parent.parent.parent / "data/sample_logic.yml")

    def test_successful_parse(self):
        logic = parse_concurrent_logic(self.SAMPLE_FILE)
        self.assertEqual(len(logic.processes), 2)
        self.assertEqual(logic.processes[0].name, "Thread1")
        self.assertEqual(logic.processes[0].actions[0].type, "lock")

    def test_invalid_file(self):
        with self.assertRaises(FileNotFoundError):
            parse_concurrent_logic("non_existent.yml")

    def test_invalid_structure(self):
        invalid_data = {"processes": [{"name": 123}]}  # 名称应为字符串
    
        # 将字典写入临时文件
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            import yaml
            yaml.dump(invalid_data, f)
            temp_path = f.name
    
        # 解析临时文件，直接捕获ValidationError
        with self.assertRaises(jsonschema.ValidationError):
            parse_concurrent_logic(temp_path)
    
    



if __name__ == "__main__":
    unittest.main()