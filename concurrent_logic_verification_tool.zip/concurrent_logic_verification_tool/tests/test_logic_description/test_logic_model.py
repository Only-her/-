# tests/test_logic_description/test_logic_model.py
import unittest
from src.logic_description.logic_model import Process, Action

class TestLogicModel(unittest.TestCase):
    def test_action_creation(self):
        action = Action(type="read", target="var1")
        self.assertEqual(action.type, "read")
        self.assertEqual(action.target, "var1")

    def test_process_ordering(self):
        actions = [
            Action(type="lock", target="mutex", order=1),
            Action(type="write", target="var1", order=0)
        ]
        process = Process(name="Thread1", actions=actions)
        self.assertEqual(process.actions[0].order, 1)  # 测试自动排序

if __name__ == "__main__":
    unittest.main()