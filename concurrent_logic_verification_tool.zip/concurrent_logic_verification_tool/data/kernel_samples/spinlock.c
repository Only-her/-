#include <linux/spinlock.h>
void example() {
    spinlock_t lock;
    spin_lock(&lock);
    // 临界区操作
    spin_unlock(&lock);
}