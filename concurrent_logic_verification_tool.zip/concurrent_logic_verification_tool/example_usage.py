# example_usage.py
from src.logic_description.parser import parse_concurrent_logic
from src.element_extraction.core import extract_elements

def main():
    # 1. 解析并发逻辑描述文件
    logic = parse_concurrent_logic("data/sample_logic.yml")
    
    # 2. 提取并发要素
    elements = extract_elements(logic)
    
    # 3. 打印提取结果
    print("共享变量分析结果:")
    for var, processes in elements["shared_variables"].items():
        print(f"  - 变量 {var} 被以下进程访问: {', '.join(processes)}")
    
    print("\n操作时序分析结果:")
    for process, sequence in elements["operation_sequences"].items():
        print(f"  - 进程 {process} 的操作序列:")
        for action in sequence:
            print(f"    * 顺序 {action['order']}: {action['type']} {action['target']}")
    
    print("\n同步原语分析结果:")
    for lock, operations in elements["sync_primitives"].items():
        print(f"  - 锁 {lock} 的操作记录:")
        for op in operations:
            print(f"    * 进程 {op[0]} 在顺序 {op[2]} 执行 {op[1]} 操作")

if __name__ == "__main__":
    main()
