#include <pthread.h>

pthread_rwlock_t rwlock = PTHREAD_RWLOCK_INITIALIZER;
int shared_data = 0;

void* reader(void* arg) {
    for (int i = 0; i < 10; i++) {
        pthread_rwlock_rdlock(&rwlock);
        printf("Read: %d\n", shared_data);  // 长期持有读锁
        sleep(1);  // 人为延长持有时间
        pthread_rwlock_unlock(&rwlock);
    }
    return NULL;
}

void* writer(void* arg) {
    pthread_rwlock_wrlock(&rwlock);
    shared_data++;
    printf("Write: %d\n", shared_data);
    pthread_rwlock_unlock(&rwlock);
    return NULL;
}

int main() {
    pthread_t t1, t2, t3;
    pthread_create(&t1, NULL, reader, NULL);
    pthread_create(&t2, NULL, reader, NULL);
    pthread_create(&t3, NULL, writer, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    return 0;
}