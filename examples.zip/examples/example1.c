#include <pthread.h>
#include <stdio.h>

pthread_mutex_t lockA = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lockB = PTHREAD_MUTEX_INITIALIZER;

void* process1(void* arg) {
    pthread_mutex_lock(&lockA);
    pthread_mutex_lock(&lockB);
    printf("Process1 in AB critical section\n");
    pthread_mutex_unlock(&lockB);
    pthread_mutex_unlock(&lockA);
    return NULL;
}

void* process2(void* arg) {
    pthread_mutex_lock(&lockB);
    pthread_mutex_lock(&lockA);
    printf("Process2 in BA critical section\n");
    pthread_mutex_unlock(&lockA);
    pthread_mutex_unlock(&lockB);
    return NULL;
}

int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, process1, NULL);
    pthread_create(&t2, NULL, process2, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    return 0;
}