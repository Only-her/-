#include <semaphore.h>
#include <pthread.h>

sem_t sem;

void* user(void* arg) {
    sem_wait(&sem);
    printf("Enter critical section\n");
    sem_post(&sem);
    return NULL;
}

void* attacker(void* arg) {
    // 恶意释放未获取的信号量
    sem_post(&sem);
    printf("Illegal semaphore release\n");
    return NULL;
}

int main() {
    sem_init(&sem, 0, 1);
    pthread_t t1, t2;
    pthread_create(&t1, NULL, user, NULL);
    pthread_create(&t2, NULL, attacker, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    sem_destroy(&sem);
    return 0;
}