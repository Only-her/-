#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
int flag = 0;

void* consumer(void* arg) {
    pthread_mutex_lock(&mutex);
    while (!flag)  // Correct pattern should use loop
        pthread_cond_wait(&cond, &mutex);
    printf("Consumed: %d\n", flag);
    pthread_mutex_unlock(&mutex);
    return NULL;
}

void* producer(void* arg) {
    pthread_mutex_lock(&mutex);
    flag = 1;
    pthread_cond_signal(&cond);  // Missing broadcast in multi-consumer scenario
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, consumer, NULL);
    pthread_create(&t2, NULL, producer, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    return 0;
}