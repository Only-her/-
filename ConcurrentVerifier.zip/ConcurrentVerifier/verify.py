# verify.py
import argparse
from parser import parse_model
from tla_generator import write_tla_and_cfg
from tlc_runner import run_tlc

def main():
    parser = argparse.ArgumentParser(
        description="TLA+ 并发逻辑模型检查工具"
    )
    parser.add_argument("yaml_file", help="并发模型的 YAML 配置文件路径")
    parser.add_argument("--tlc", dest="tlc_path", default="tla2tools.jar",
                        help="TLC 工具(tla2tools.jar)路径，默认为当前目录")
    args = parser.parse_args()
    
    yaml_path = args.yaml_file
    tlc_path = args.tlc_path
    
    # 1. 解析 YAML 模型
    try:
        model = parse_model(yaml_path)
    except Exception as e:
        print(f"解析 YAML 文件失败: {e}")
        return 1  # 非正常退出
    
    # 2. 生成 TLA+ 规格和配置文件
    spec_name, tla_file, cfg_file = write_tla_and_cfg(model, yaml_path)
    print(f"已生成 TLA+ 模块: {tla_file}")
    print(f"已生成 TLC 配置: {cfg_file}")
    
    # 3. 调用 TLC 进行模型检查
    print("开始模型检查...")
    code, output = run_tlc(spec_name, tla_file, cfg_file, tlc_path)
    
    # 4. 输出结果
    if output:
        print(output)
    if code == 0:
        print("模型检查完成。")
    else:
        print(f"TLC 检查过程中出现错误，退出码: {code}")
    return code

if __name__ == "__main__":
    main()
