# tlc_runner.py
import subprocess

def run_tlc(spec_name, tla_path, cfg_path, tlc_path="tla2tools.jar"):
    """调用 TLC 模型检查器检查 spec_name 模型，返回退出码和输出。"""
    # 构造 TLC 命令
    cmd = [
        "java", "-cp", tlc_path, "tlc2.TLC",
        "-config", cfg_path, tla_path
    ]
    # 运行 TLC 命令，捕获输出
    result = subprocess.run(cmd, capture_output=True, text=True)
    output = result.stdout + result.stderr
    return result.returncode, output
