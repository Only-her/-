# tla_generator.py
def generate_tla_module(model, spec_name):
    """根据模型数据生成 TLA+ 规格字符串和不变式名称列表。"""
    lines = []
    lines.append(f"---- MODULE {spec_name} ----")
    lines.append("EXTENDS TLC\n")  # 扩展 TLC 模块支持字符串等
    
    # 变量声明
    vars_list = list(model.get('variables', {}).keys())
    if vars_list:
        lines.append("VARIABLES " + ", ".join(vars_list) + "\n")
    
    # 初始条件 Init
    init_conditions = []
    for var, val in model.get('variables', {}).items():
        # 根据值类型格式化初始值
        if isinstance(val, bool):
            val_expr = "TRUE" if val else "FALSE"
        elif isinstance(val, str):
            val_expr = f"\"{val}\""
        elif isinstance(val, (int, float)):
            val_expr = str(val)
        elif isinstance(val, list):
            # 列表作为集合处理
            elements = []
            for item in val:
                if isinstance(item, bool):
                    elements.append("TRUE" if item else "FALSE")
                elif isinstance(item, str):
                    elements.append(f"\"{item}\"")
                else:
                    elements.append(str(item))
            val_expr = "{" + ", ".join(elements) + "}"
        else:
            val_expr = str(val)
        init_conditions.append(f"{var} = {val_expr}")
    if init_conditions:
        lines.append("Init ==")
        # 将每个初始条件用 /\ 连接，多行表示
        lines.append("    " + init_conditions[0])
        for cond in init_conditions[1:]:
            lines.append("    /\\ " + cond)
        lines.append("")  # 空行
    
    # 下一步关系 Next
    transition_forms = []
    for proc_name, proc in model.get('processes', {}).items():
        for trans in proc.get('transitions', []):
            guard = trans.get('precondition', "") or ""  # 前置条件
            effect = trans.get('effect', {})            # 后置效果
            # 将前置条件中的 and, or, not, != 等替换为 TLA+ 符号
            guard_expr = guard.replace("&&", " /\\ ").replace("||", " \\/ ")
            guard_expr = guard_expr.replace(" and ", " /\\ ").replace(" or ", " \\/ ")
            guard_expr = guard_expr.replace("!=", " /= ").replace("not ", "~")
            guard_expr = guard_expr.replace("True", "TRUE").replace("False", "FALSE")
            guard_expr = guard_expr.strip()
            # 处理效果赋值子公式
            effects_exprs = []
            for var, new_val in effect.items():
                # 根据新值类型生成赋值表达式
                if isinstance(new_val, bool):
                    val_expr = "TRUE" if new_val else "FALSE"
                elif isinstance(new_val, str):
                    val_expr = f"\"{new_val}\""
                else:
                    val_expr = str(new_val)
                effects_exprs.append(f"{var}' = {val_expr}")
            # 其它未变化的变量保持不变
            for var in vars_list:
                if var not in effect:
                    effects_exprs.append(f"{var}' = {var}")
            # 将所有赋值条件用 /\ 连接
            effect_expr = " /\\ ".join(effects_exprs)
            # 如果有前置条件，组合前置 /\ 效果；否则直接使用效果
            if guard_expr:
                transition_forms.append(f"({guard_expr}) /\\ {effect_expr}")
            else:
                transition_forms.append(effect_expr)
    if transition_forms:
        lines.append("Next ==")
        # 第一条转换不加 \/, 后续每条前加 \/
        lines.append("    " + "(" + transition_forms[0] + ")")
        for trans_expr in transition_forms[1:]:
            lines.append("    \\/ (" + trans_expr + ")")
        lines.append("")  # 空行
    
    # 不变式定义
    inv_names = []
    for idx, inv in enumerate(model.get('invariants', []), start=1):
        inv_expr = inv
        inv_expr = inv_expr.replace(" and ", " /\\ ").replace(" or ", " \\/ ")
        inv_expr = inv_expr.replace("!=", " /= ").replace("not ", "~")
        inv_expr = inv_expr.replace("True", "TRUE").replace("False", "FALSE")
        name = f"Inv{idx}"
        lines.append(f"{name} == {inv_expr}")
        inv_names.append(name)
    lines.append("")  # 不变式块结束空行
    
    lines.append("====")  # 模块结尾
    return "\n".join(lines), inv_names

def write_tla_and_cfg(model, yaml_path):
    """生成 TLA+ 模块和 .cfg 配置文件，并写入输出目录。"""
    import os
    spec_name = os.path.splitext(os.path.basename(yaml_path))[0]  # 以YAML文件名作为规格名
    tla_content, inv_names = generate_tla_module(model, spec_name)
    # 将 .tla 文件写入 output/ 目录
    tla_path = os.path.join("output", f"{spec_name}.tla")
    with open(tla_path, 'w', encoding='utf-8') as f_tla:
        f_tla.write(tla_content)
    # 生成并写入 .cfg 文件
    cfg_path = os.path.join("output", f"{spec_name}.cfg")
    with open(cfg_path, 'w', encoding='utf-8') as f_cfg:
        f_cfg.write(f"INIT Init\nNEXT Next\n")
        if inv_names:
            f_cfg.write("INVARIANTS " + " ".join(inv_names) + "\n")
    return spec_name, tla_path, cfg_path
