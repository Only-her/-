# parser.py
import yaml

def parse_model(yaml_path):
    """解析 YAML 配置文件，返回模型数据字典。"""
    with open(yaml_path, 'r', encoding='utf-8') as f:
        model = yaml.safe_load(f)  # 安全加载YAML内容&#8203;:contentReference[oaicite:3]{index=3}
    # 简单完整性校验，例如必须包含variables和processes键
    if 'variables' not in model or 'processes' not in model:
        raise ValueError("YAML文件缺少必要的 'variables' 或 'processes' 部分")
    # 可以在此处添加更多校验逻辑（如类型检查、不变式语法检查等）
    return model
